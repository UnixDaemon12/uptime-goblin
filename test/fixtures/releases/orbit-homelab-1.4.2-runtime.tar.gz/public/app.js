const $ = selector => document.querySelector(selector);
const esc = value =>
  String(value ?? '').replace(
    /[&<>"']/g,
    char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]
  );
const paths = {
  server: 'M3 3h18v7H3z M3 14h18v7H3z M7 6.5h.01 M7 17.5h.01',
  terminal: 'm5 6 5 6-5 6 M13 18h6',
  window: 'M3 3h8v8H3z M14 3h7v8h-7z M3 14h8v7H3z M14 14h7v7h-7z',
  network: 'M12 8v5 M5 13h14 M5 13v4 M19 13v4 M9 2h6v6H9z M2 17h6v5H2z M16 17h6v5h-6z',
  drive: 'M5 4h14l3 12H2z M2 16v5h20v-5 M16 18.5h.01 M19 18.5h.01',
  layers: 'm12 3 10 5-10 5L2 8z M2 12l10 5 10-5 M2 16l10 5 10-5',
  play: 'm8 4 12 8-12 8z',
  activity: 'M2 12h4l3-9 5 18 3-9h5',
  ticket: 'M4 5h16v5a2 2 0 0 0 0 4v5H4v-5a2 2 0 0 0 0-4z M14 5v3 M14 11v2 M14 16v3',
  tv: 'M3 7h18v14H3z M7 2l5 5 5-5',
  film: 'M3 3h18v18H3z M7 3v18 M17 3v18 M3 8h4 M3 16h4 M17 8h4 M17 16h4',
  radar: 'M12 3a9 9 0 1 0 9 9 M12 7a5 5 0 1 0 5 5 M12 12 21 3 M17 3h4v4',
  download: 'M12 3v12 m-5-5 5 5 5-5 M4 16v5h16v-5',
  shield: 'M12 2 3 6v6c0 6 9 10 9 10s9-4 9-10V6z m-5 10 3 3 5-6',
  route: 'M5 3v18 M5 7h9c5 0 5 10 0 10h-3 M3 3h4 M3 21h4 m11-8-4 4 4 4',
  lock: 'M5 10h14v12H5z M8 10V6a4 4 0 0 1 8 0v4 M12 15v3',
  orbit: 'M12 3a9 9 0 1 0 9 9 M15 3a3 3 0 1 0 6 0 M12 10v4 M10 12h4',
  grid: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
  chevron: 'm6 9 6 6 6-6',
  external: 'M14 3h7v7 m-1-6-9 9 M10 3H3v18h18v-7',
  chart: 'M3 3v18h18 M6 16l4-6 4 3 6-8',
  pause: 'M8 5v14 M16 5v14',
  plus: 'M12 5v14 M5 12h14',
  gamepad:
    'M7 7h10c3 0 4 4 4 10s-4 3-6-1H9c-2 4-6 7-6 1s1-10 4-10z M7 9v6 M4 12h6 M16 11h.01 M18 14h.01',
  globe: 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0 M3 12h18 M12 3a19 19 0 0 1 0 18 19 19 0 0 1 0-18',
  check: 'm5 12 4 4L19 6',
};
function icon(type, size = 20) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[type] || paths.grid}"/></svg>`;
}
const states = {
  unconfigured: 'Not connected',
  live: 'Connected',
  error: 'Check failed',
  stale: 'Last reading · stale',
  disabled: 'Paused',
  link: 'Link only',
  collecting: 'Connecting',
};
let data,
  expanded = null,
  range = '24h',
  selectedMetric = '',
  settingsId = null,
  draftRules = [],
  editingRule = null,
  draftCredentials = {},
  loading = false,
  loadPromise,
  reloadRequested = false,
  toastTimer,
  testController,
  historyRequest = null,
  chartPointer = null;
let configurationSection = null,
  acceptedHash = location.hash,
  acceptedIndex = 0,
  restoringRoute = false,
  pageBaseline = '',
  drawerBaseline = '',
  drawerRulesBaseline = '',
  // Configuration revision the settings page and the source drawer were drawn from.
  pageRevision,
  drawerRevision,
  displayTimeZone,
  unsupportedTimeZone = null,
  routeInitialized = false,
  firstLoad = true,
  busyForm = null,
  passwordChangePending = false,
  reauthenticationRequired = false,
  dashboardPollTimer;
const activeApiRequests = new Set();
// Only the expanded card's history is kept: a large source's history can be many MB.
const historyCache = new Map();
const charts = new Map();
function format(value, unit = '') {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  if (unit === 'bytes' || unit === 'bytes/s') {
    let n = value,
      i = 0;
    const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
    while (Math.abs(n) >= 1024 && i < 4) {
      n /= 1024;
      i++;
    }
    return `${n.toLocaleString(undefined, { maximumFractionDigits: i ? 1 : 0 })} ${units[i]}${unit === 'bytes/s' ? '/s' : ''}`;
  }
  if (unit === 'seconds') {
    if (value >= 86400) return `${(value / 86400).toFixed(1)} d`;
    if (value >= 3600) return `${(value / 3600).toFixed(1)} h`;
    if (value >= 60) return `${Math.round(value / 60)} m`;
    return `${Math.round(value)} s`;
  }
  return `${value.toLocaleString(undefined, { maximumFractionDigits: Math.abs(value) < 10 ? 2 : 1 })}${unit === '%' ? '%' : unit ? ' ' + unit : ''}`;
}
/** Checks the saved zone once per configuration load; browsers support different zone IDs. */
function checkTimeZone() {
  const zone = data.config.appearance?.timezone;
  displayTimeZone = undefined;
  unsupportedTimeZone = null;
  if (!zone || zone === 'local') return;
  try {
    new Intl.DateTimeFormat(undefined, { timeZone: zone });
    displayTimeZone = zone;
  } catch {
    // Show local time rather than let one RangeError stop every render.
    unsupportedTimeZone = zone;
  }
}
function timeZoneNote() {
  if (!unsupportedTimeZone) return '';
  const local = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return `<p class="field-error">This browser does not support the saved time zone “${esc(unsupportedTimeZone)}”, so it shows times in its own local time zone${local ? ` (${esc(local)})` : ''}. Choose “local” or an IANA name such as America/Chicago.</p>`;
}
function dateOptions(options = {}) {
  const a = data?.config.appearance || {};
  return {
    ...options,
    ...(displayTimeZone ? { timeZone: displayTimeZone } : {}),
    ...(a.timeFormat === '12h'
      ? { hour12: true }
      : a.timeFormat === '24h'
        ? { hour12: false }
        : {}),
  };
}
function dateTime(t, options) {
  if (!t) return '—';
  try {
    return new Date(t).toLocaleString([], dateOptions(options));
  } catch {
    return new Date(t).toLocaleString([], options);
  }
}
function when(t) {
  return dateTime(t, { hour: '2-digit', minute: '2-digit' });
}
function launchAttributes() {
  return data?.config.appearance?.openInNewTab === false
    ? ''
    : 'target="_blank" rel="noopener noreferrer"';
}
function applyAppearance() {
  const a = data.config.appearance || {};
  document.documentElement.style.setProperty(
    '--mint',
    `var(--${['cyan', 'orange', 'blue', 'violet', 'amber', 'pink', 'green'].includes(a.accent) ? a.accent : 'cyan'})`
  );
  document.documentElement.dataset.density = a.density || 'comfortable';
  document.documentElement.dataset.columns = a.columns || 'auto';
  document.documentElement.dataset.reduceMotion = String(!!a.reduceMotion);
  $('.summary').hidden = a.showSummary === false;
  $('#dashboard-title').textContent = data.config.title || 'Overview';
  $('#dashboard-subtitle').textContent = data.config.subtitle || '';
  $('#dashboard-subtitle').hidden = !data.config.subtitle;
  document.title = `${data.config.title || 'Orbit'} · Homelab`;
  clock();
}

function toast(message) {
  (document.querySelector('dialog[open]') || document.body).append($('#toast'));
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($('#toast').hidden = true), 4500);
}
// AbortSignal.any needs Safari 17.4 or later; older wall-mounted iPads still run Orbit.
function eitherSignal(a, b) {
  if (AbortSignal.any) return AbortSignal.any([a, b]);
  const both = new AbortController();
  for (const signal of [a, b]) {
    if (signal.aborted) both.abort(signal.reason);
    else signal.addEventListener('abort', () => both.abort(signal.reason), { once: true });
  }
  return both.signal;
}
async function api(url, options = {}) {
  if (reauthenticationRequired)
    throw new Error('Sign in again with your new password to continue.');
  if (passwordChangePending && url !== '/api/auth/password')
    throw new Error('A password update is in progress.');
  const controller = new AbortController();
  activeApiRequests.add(controller);
  try {
    const res = await fetch(url, {
      ...options,
      signal: options.signal ? eitherSignal(options.signal, controller.signal) : controller.signal,
      headers: { 'Content-Type': 'application/json', 'X-Orbit-Request': '1', ...options.headers },
    });
    const body = await res.text();
    let content;
    try {
      content = JSON.parse(body);
    } catch {
      // Not Orbit's JSON, e.g. a reverse proxy's 502/504 page. `status` stays unset so
      // callers such as changePassword() treat the outcome as unknown.
      throw new Error(
        `Orbit returned an unexpected response (HTTP ${res.status}). Check the reverse proxy.`
      );
    }
    if (!res.ok) {
      const error = new Error(content.error || 'Could not complete that request');
      error.status = res.status;
      error.retryAfter = Number(res.headers.get('Retry-After')) || 0;
      throw error;
    }
    return content;
  } finally {
    activeApiRequests.delete(controller);
  }
}
// Configuration writes name the revision they were based on, so the server refuses (409)
// a write that would silently revert a change saved meanwhile on another device or tab.
const ifMatch = revision => (Number.isInteger(revision) ? { 'If-Match': String(revision) } : {});
const conflictMessage = 'This was changed on another device or tab, so your change was not saved.';
// This tab's configuration writes go out one at a time, each naming the revision current when
// it is sent, and a success is applied here at once rather than when load() returns. A quick
// second action then builds on the first instead of being refused as a conflict.
let configWrites = Promise.resolve(),
  // The newest revision this tab's own writes produced, and how many older dashboard
  // snapshots have been skipped in a row because of it.
  writtenRevision = 0,
  staleSnapshots = 0;
/**
 * Sends a configuration write based on `revision()`, read when it is sent (`conditional:
 * false` sends no If-Match). `apply(config, result)` brings this tab's copy of the
 * configuration up to the written revision; `source` is the source the write changed.
 */
function writeConfig(url, options, { revision, apply, source = null, conditional = true }) {
  const write = configWrites.then(async () => {
    const based = revision();
    const result = await api(url, { ...options, headers: conditional ? ifMatch(based) : {} });
    // A newer write of this tab explains any older snapshot still on its way, so the count
    // of skipped snapshots (meant for a server whose configuration went back) starts again.
    if (Number.isInteger(result.revision) && result.revision > writtenRevision) {
      writtenRevision = result.revision;
      staleSnapshots = 0;
    }
    adoptWrite(based, result.revision, config => apply(config, result), source);
    return result;
  });
  configWrites = write.catch(() => {});
  return write;
}
/**
 * Moves the copies drawn from revision `based` to `revision`, which this tab's write created.
 * Only a write that was the sole change since `based` qualifies; anything else is left to
 * load(), so a change saved on another device is never skipped over.
 */
function adoptWrite(based, revision, apply, source) {
  if (!Number.isInteger(based) || revision !== based + 1) return;
  if (data.config.revision === based) {
    apply(data.config);
    data.config.revision = revision;
  }
  // Settings forms show no source fields, and a settings save came from the form itself.
  if (pageRevision === based) pageRevision = revision;
  // A drawer open on the source this write changed still shows it as it was.
  if (drawerRevision === based && settingsId !== source) drawerRevision = revision;
}
const replaceService = (config, { service }) => {
  config.services = config.services.map(s => (s.id === service.id ? service : s));
};
/** Settings as this tab saved them; the next load() brings the server's normalized copy. */
function mergeSettings(config, input) {
  for (const [key, value] of Object.entries(input))
    config[key] = value && typeof value === 'object' ? { ...config[key], ...value } : value;
}
// Brings `target`'s children in line with `html` but keeps nodes that did not change, so
// a refresh does not drop focus, close an open <select> or reset hover state.
function patchHtml(target, html) {
  const template = document.createElement('template');
  template.innerHTML = html;
  patchChildren(target, template.content);
}
const nodeKey = node =>
  node.nodeType === 1 ? node.id || node.dataset?.id || node.dataset?.group || '' : '';
const sameNode = (a, b) => a.nodeName === b.nodeName && nodeKey(a) === nodeKey(b);
function patchChildren(target, source) {
  const nodes = [...source.childNodes],
    // Keys still to be placed: a keyed node whose key is not among them was removed.
    pending = new Set(nodes.map(nodeKey).filter(Boolean));
  let current = target.firstChild;
  for (const node of nodes) {
    const key = nodeKey(node);
    // A keyed node further on is moved into place (a reorder, e.g. 'Needs attention first'),
    // so nothing is rebuilt. Removed nodes before it go. Nodes still to come are moved out
    // of its way when it holds the focus, since moving the focused node would blur it and
    // close an open dropdown; otherwise it is moved up to them.
    if (current && key && !sameNode(current, node)) {
      let later = current.nextSibling;
      while (later && !sameNode(later, node)) later = later.nextSibling;
      while (later && current !== later) {
        if (pending.has(nodeKey(current)) && !later.contains(document.activeElement)) {
          target.insertBefore(later, current);
          current = later;
        } else {
          const next = current.nextSibling;
          if (pending.has(nodeKey(current))) target.append(current);
          else current.remove();
          current = next;
        }
      }
    }
    pending.delete(key);
    if (current && sameNode(current, node)) {
      if (!current.isEqualNode(node)) patchNode(current, node);
      current = current.nextSibling;
    } else target.insertBefore(node, current);
  }
  while (current) {
    const removed = current;
    current = current.nextSibling;
    removed.remove();
  }
}
function patchNode(current, node) {
  if (current.nodeType !== 1) {
    current.nodeValue = node.nodeValue;
    return;
  }
  for (const { name } of [...current.attributes])
    if (!node.hasAttribute(name)) current.removeAttribute(name);
  for (const { name, value } of node.attributes)
    if (current.getAttribute(name) !== value) current.setAttribute(name, value);
  // renderGraph() owns the chart area and redraws it itself.
  if (!current.hasAttribute('data-graph')) patchChildren(current, node);
}
function stateFor(id) {
  return data.services.find(s => s.id === id) || { status: 'unconfigured', metrics: [] };
}
function render() {
  if (!data) return;
  const focused = document.activeElement;
  const focusKey = focused?.dataset.expand
    ? `[data-expand="${CSS.escape(focused.dataset.expand)}"]`
    : focused?.dataset.toggle
      ? `[data-toggle="${CSS.escape(focused.dataset.toggle)}"]`
      : focused?.id === 'metric-select'
        ? '#metric-select'
        : null;
  applyAppearance();
  const allServices = data.config.services,
    a = data.config.appearance || {},
    services = allServices.filter(
      s =>
        s.showOnDashboard !== false &&
        (a.showPaused !== false || s.enabled) &&
        (a.showUnconfigured !== false || stateFor(s.id).status !== 'unconfigured')
    );
  if (a.sortBy === 'name') services.sort((x, y) => x.name.localeCompare(y.name));
  if (a.sortBy === 'status') {
    const order = {
      error: 0,
      stale: 1,
      collecting: 2,
      live: 3,
      unconfigured: 4,
      disabled: 5,
      link: 6,
    };
    services.sort(
      (x, y) =>
        (order[stateFor(x.id).status] ?? 9) - (order[stateFor(y.id).status] ?? 9) ||
        x.name.localeCompare(y.name)
    );
  }
  const active = allServices.filter(s => s.enabled),
    monitored = data.services.filter(s => s.configured && active.some(c => c.id === s.id)),
    live = monitored.filter(s => s.status === 'live').length,
    paused = allServices.length - active.length;
  $('#connected-count').innerHTML = `${live}<span> / ${monitored.length}</span>`;
  $('#connected-note').textContent = monitored.length
    ? paused
      ? `${paused} source${paused === 1 ? '' : 's'} paused`
      : 'Configured sources'
    : 'Connect your first source';
  $('#connection').textContent = live
    ? 'Collection active'
    : monitored.length
      ? 'Checking sources'
      : 'Awaiting connections';
  $('#connection').classList.toggle('live', live > 0);
  $('#alert-count').textContent = data.alerts.length;
  $('#alert-note').textContent =
    data.config.alerts?.enabled === false
      ? 'Alert evaluation paused'
      : data.alerts.length
        ? 'Requires your attention'
        : monitored.length
          ? 'No active alerts'
          : 'No measurements yet';
  $('#alerts-button').classList.toggle('has-alert', data.alerts.length > 0);
  $('#last-collected').textContent = when(data.lastCollected);
  $('#retention').innerHTML = `${data.config.retentionDays}<span> days</span>`;
  $('#source-count').textContent =
    services.length === allServices.length
      ? services.length
      : `${services.length} of ${allServices.length}`;
  $('#footer-status').textContent = `Every ${data.config.pollSeconds}s · stored locally`;
  patchHtml(
    $('#services'),
    services.length
      ? [...new Set(services.map(s => s.group))]
          .map(group => {
            const items = services.filter(s => s.group === group);
            return `<section class="group" data-group="${esc(group)}"><div class="group-heading"><h2>${esc(group)}</h2><span>${String(items.length).padStart(2, '0')}</span></div><div class="cards">${items.map(card).join('')}</div></section>`;
          })
          .join('')
      : allServices.length
        ? '<div class="empty-history"><h4>A quieter view</h4><p>Your sources are hidden by your dashboard preferences. Monitoring continues for enabled connections.</p><a class="button" href="#configure/sources">Manage sources</a></div>'
        : '<div class="empty-history"><h4>Room for your homelab</h4><p>Add your first source to start collecting measurements.</p><button class="button" data-add-source>Add a source</button></div>'
  );
  if (expanded) renderGraph(expanded);
  if (focusKey && !focused.isConnected) $(focusKey)?.focus({ preventScroll: true });
}
function card(s) {
  const state = stateFor(s.id),
    open = expanded === s.id,
    metrics = state.metrics?.slice(0, 3) || [],
    // The effective collector decides, not the card type: a Website card can be switched
    // to Bookmark only, and a Bookmark card to a Website check.
    labels =
      state.collector === 'http'
        ? ['Response', 'Available', 'HTTP status']
        : state.collector === 'none'
          ? []
          : s.labels;
  const count = Math.max(labels.length, metrics.length);
  return `<article class="service ${open ? 'expanded' : ''} ${!s.enabled ? 'paused' : ''}" style="--accent:var(--${esc(s.color)})" data-id="${esc(s.id)}">
 <div class="card-top"><div class="service-icon">${icon(s.icon)}</div><div class="service-title"><h3>${s.url ? `<a href="${esc(s.url)}" ${launchAttributes()}>${esc(s.name)} ${icon('external', 12)}</a>` : esc(s.name)}</h3><span class="state ${esc(state.status)}">${states[state.status] || 'Unknown'}</span></div>
 <div class="card-controls"><button class="pause-control ${!s.enabled ? 'is-paused' : ''}" data-toggle="${esc(s.id)}" aria-label="${s.enabled ? 'Pause' : 'Resume'} ${esc(s.name)}" title="${s.enabled ? 'Pause monitoring' : 'Resume monitoring'}">${icon(s.enabled ? 'pause' : 'play', 13)}</button><button class="expand" data-expand="${esc(s.id)}" aria-expanded="${open}" aria-controls="detail-${esc(s.id)}" aria-label="${open ? 'Hide' : 'Show'} stats for ${esc(s.name)}">${icon('chevron', 15)}</button></div></div>
 ${count ? `<div class="mini-metrics">${Array.from({ length: Math.min(count, 3) }, (_, i) => `<div><span>${esc(metrics[i]?.label || labels[i] || 'Measurement')}</span><strong class="${metrics[i] ? '' : 'empty'}">${esc(metrics[i] ? format(metrics[i].value, metrics[i].unit) : '—')}</strong></div>`).join('')}</div>` : `<p class="utility-note">${s.url ? 'Your workspace, one click away' : 'Add a destination to launch this service'}</p>`}
 <div id="detail-${esc(s.id)}" ${open ? '' : 'hidden'} class="detail">${open ? detail(s, state) : ''}</div></article>`;
}
function detail(s, state) {
  const hasMetrics = state.metrics?.length;
  return `<div class="detail-top"><div><h4>${esc(s.name)} <span class="muted">/</span> Insights</h4><p>${!s.enabled ? 'Monitoring paused · saved readings are preserved' : state.lastSuccess ? 'Last successful reading ' + dateTime(state.lastSuccess) : 'Current measurements and historical trends'}</p></div><div class="detail-actions"><div class="ranges" aria-label="History period">${['1h', '6h', '24h', '7d', '30d'].map(r => `<button class="range-button ${range === r ? 'active' : ''}" data-range="${r}" aria-pressed="${range === r}">${r}</button>`).join('')}</div><button class="button" data-configure="${esc(s.id)}">Configure</button></div></div>
 ${state.error && s.enabled ? `<div class="detail-error">${esc(state.error)}</div>` : ''}
 ${hasMetrics ? `<div id="graph-${esc(s.id)}" class="graph-layout" data-graph><div class="loading">Loading history…</div></div>` : `<div class="empty-history"><div class="empty-symbol">${icon('chart', 27)}</div><h4>${!s.enabled ? 'Taking a breather' : state.collector === 'none' ? 'A place for your service' : state.configured ? 'No measurements yet' : 'Ready when you are'}</h4><p>${!s.enabled ? 'Resume this source whenever you want to collect new readings. Existing settings are saved.' : state.collector === 'none' ? 'Set a destination URL to open this service from Orbit.' : state.configured ? (state.error ? 'Orbit has this connection but has not received a reading yet. Check the error above, then edit the connection if needed.' : 'Waiting for the first reading. Historical graphs build automatically as readings arrive.') : 'Connect this source to see real measurements. Historical graphs build automatically as readings arrive.'}</p><button class="button" ${!s.enabled ? `data-toggle="${esc(s.id)}"` : `data-configure="${esc(s.id)}"`}>${!s.enabled ? 'Resume monitoring' : state.configured ? 'Edit connection' : 'Connect ' + esc(s.name)} ${icon('external', 12)}</button></div>`}
 <div class="detail-foot"><span>${!s.enabled ? 'Polling and alerts are paused' : hasMetrics ? (s.rules.length ? `${s.rules.length} metric rule${s.rules.length === 1 ? '' : 's'} · connection monitored` : 'Connection monitored · no metric rules') : 'No measurements collected'}</span><div class="detail-foot-actions">${hasMetrics ? `<button class="quiet-button" data-export-history="${esc(s.id)}">Export ${esc(range)} CSV</button>` : ''}${s.url ? `<a href="${esc(s.url)}" ${launchAttributes()}>Open ${esc(s.name)} ↗</a>` : '<span>Destination not set</span>'}</div></div>`;
}
/** Refreshes `data` and the dashboard. Resolves to true when fresh data was applied. */
async function load() {
  if (passwordChangePending || reauthenticationRequired) return false;
  // A load already in flight may have fetched before the caller's change, so run one
  // more fetch after it and resolve every caller with that one.
  if (loading) {
    reloadRequested = true;
    return loadPromise;
  }
  loading = true;
  loadPromise = (async () => {
    try {
      let loaded;
      do {
        reloadRequested = false;
        loaded = await loadOnce();
      } while (reloadRequested && !passwordChangePending && !reauthenticationRequired);
      return loaded;
    } finally {
      loading = false;
    }
  })();
  return loadPromise;
}
async function loadOnce() {
  let fresh;
  try {
    fresh = await api('/api/dashboard');
  } catch (e) {
    if (passwordChangePending || reauthenticationRequired) return false;
    // 401 and 429 come from Orbit's sign-in, not from collection.
    const signIn = e.status === 401 || e.status === 429,
      message =
        e.status === 401
          ? 'Orbit did not accept this browser’s sign-in. Reload the page to sign in again.'
          : e.status === 429
            ? `${e.message}${e.retryAfter > 1 ? ` Sign-in is paused for about ${waitTime(e.retryAfter)}.` : ''} Readings resume automatically afterwards.`
            : 'Orbit cannot reach its collector. Displayed readings may be stale.';
    $('#notice').hidden = false;
    $('#notice').textContent = message;
    $('#connection').textContent = !signIn
      ? 'Collector unavailable'
      : e.status === 401
        ? 'Sign in again'
        : 'Sign-in paused';
    $('#connection').classList.remove('live');
    if (!data && location.hash.startsWith('#configure')) {
      $('#dashboard-page').hidden = true;
      $('#configuration-page').hidden = false;
      $('#configuration-content').innerHTML =
        `<div class="settings-hint">${signIn ? esc(message) : 'Configuration is unavailable until Orbit reconnects. Try refreshing the page.'}</div>`;
    }
    return false;
  }
  // A snapshot the server built before this tab's own write can arrive after it; applying it
  // would roll back the revision and the change. Fetch again instead (a few times at most,
  // in case the server's configuration really went back, such as after a restore).
  if (fresh.config.revision < writtenRevision && staleSnapshots < 3) {
    staleSnapshots++;
    reloadRequested = true;
    return false;
  }
  staleSnapshots = 0;
  writtenRevision = fresh.config.revision;
  data = fresh;
  checkTimeZone();
  if (firstLoad) {
    range = data.config.appearance?.defaultRange || '24h';
    firstLoad = false;
  }
  // A display bug must not be reported as a collector outage, and must not stop routing.
  let renderError = null;
  try {
    render();
  } catch (e) {
    renderError = e;
  }
  try {
    if (!routeInitialized) {
      routeInitialized = true;
      renderRoute(false);
    } else refreshConfiguration();
  } catch (e) {
    renderError ??= e;
  }
  // Not awaited: a slow history download must not hold up, or stack, dashboard polls.
  if (expanded && !configurationSection && historyDue(expanded)) loadHistory(expanded);
  // Collection and alerts continue, but new readings are not being saved.
  $('#notice').hidden = !data.storage && !renderError;
  if (data.storage)
    $('#notice').textContent =
      `Orbit cannot save new readings to its history database (${data.storage.code}) since ${dateTime(data.storage.since)}. The disk may be full. Alerts still run; lower history retention or free disk space.`;
  else if (renderError) {
    console.error(renderError);
    $('#notice').textContent =
      `This page could not be fully displayed (${renderError.message}). Reload the page. Collection continues on the Orbit server.`;
  }
  return true;
}
function waitTime(seconds) {
  const minutes = Math.ceil(seconds / 60);
  return seconds < 60 ? `${seconds} seconds` : `${minutes} minute${minutes === 1 ? '' : 's'}`;
}
/** Drops history kept for cards other than the expanded one. */
function forgetHistory() {
  for (const map of [historyCache, charts])
    for (const id of map.keys()) if (id !== expanded) map.delete(id);
}
/**
 * Whether the expanded card's history should be fetched again. A chart only gains a new
 * bucket every range/300, so it is refreshed once its window has moved on by a bucket (at
 * most once per 15 s poll), also while no readings arrive, e.g. when paused. A change of
 * status (paused, resumed, failing, recovered) shows at once, and so does the next reading
 * after this tab's own Refresh or change to the source (refreshHistory).
 */
function historyDue(id) {
  const cached = historyCache.get(id);
  if (!cached || cached.range !== range || cached.error) return true;
  const state = stateFor(id);
  return (
    state.status !== cached.status ||
    (cached.followReading && (state.lastAttempt ?? state.lastSuccess) !== cached.lastAttempt) ||
    Date.now() - cached.fetchedAt >= Math.max(15000, (cached.to - cached.from) / 300)
  );
}
/**
 * After this tab's own Refresh or change to a source, its open chart is fetched again at the
 * next load, and once more when the next reading or failure arrives.
 */
function refreshHistory(id) {
  const cached = historyCache.get(id);
  if (cached) Object.assign(cached, { fetchedAt: -Infinity, followReading: true });
}
function loadHistory(id) {
  if (!id || !stateFor(id).metrics?.length) return;
  const requestedRange = range,
    { status } = stateFor(id),
    lastAttempt = stateFor(id).lastAttempt ?? stateFor(id).lastSuccess;
  if (historyRequest?.id === id && historyRequest.range === requestedRange)
    return historyRequest.promise;
  const request = { id, range: requestedRange };
  historyRequest = request;
  request.promise = (async () => {
    try {
      const history = await api(`/api/history/${encodeURIComponent(id)}?range=${requestedRange}`);
      // A response for a period or card the user has left must never be drawn later.
      if (expanded !== id || range !== requestedRange) return;
      const previous = historyCache.get(id);
      historyCache.set(id, {
        ...history,
        range: requestedRange,
        fetchedAt: Date.now(),
        lastAttempt,
        status,
        // Keep watching after the fetch refreshHistory() forced, and until one brings a
        // newer reading: that fetch may have run before the reading arrived.
        followReading:
          !!previous?.followReading &&
          (previous.fetchedAt === -Infinity || previous.lastAttempt === lastAttempt),
      });
    } catch (e) {
      if (expanded !== id || range !== requestedRange) return;
      // Readings already drawn for this period stay; the next poll tries again.
      if (historyCache.get(id)?.range !== requestedRange || historyCache.get(id).error)
        historyCache.set(id, { range: requestedRange, error: e.message, fetchedAt: Date.now() });
    } finally {
      if (historyRequest === request) historyRequest = null;
    }
    renderGraph(id);
  })();
  return request.promise;
}
function renderGraph(id) {
  const history = historyCache.get(id),
    state = stateFor(id),
    element = $(`#graph-${CSS.escape(id)}`);
  // Skip while the dashboard is hidden: the layout has no width to draw to.
  if (!element || !element.getClientRects().length) return;
  if (!history || history.range !== range || history.error) {
    charts.delete(id);
    patchHtml(
      element,
      history?.range === range
        ? `<div class="detail-error">History is unavailable. ${esc(history.error)}</div>`
        : '<div class="loading">Loading history…</div>'
    );
    return;
  }
  const metrics = state.metrics;
  if (!metrics.some(m => m.key === selectedMetric)) selectedMetric = metrics[0]?.key;
  const current = metrics.find(m => m.key === selectedMetric);
  if (!current) return;
  const points = history.points.map(p => ({
    time: p.time,
    gapBefore: p.gapBefore,
    value: p.ok ? p.metrics.find(m => m.key === selectedMetric)?.value : null,
  }));
  const valid = points.filter(p => Number.isFinite(p.value));
  let chart;
  if (!valid.length) {
    charts.delete(id);
    chart = `<div class="empty-history compact"><div class="empty-symbol">${icon('chart', 23)}</div><h4>No readings in this period</h4><p>Try a longer time range or allow this source to collect new readings.</p></div>`;
  } else {
    // Match the drawing to the chart's CSS box so it is not scaled or letterboxed.
    const style = getComputedStyle(element),
      w = Math.max(250, parseFloat(style.gridTemplateColumns) || 700),
      h = parseFloat(style.getPropertyValue('--chart-height')) || 205,
      left = 67,
      right = 12,
      top = 18,
      bottom = 34;
    let min = Math.min(...valid.map(p => p.value)),
      max = Math.max(...valid.map(p => p.value));
    if (min === max) {
      const pad = Math.max(Math.abs(max) * 0.05, 1);
      min = min >= 0 ? Math.max(0, min - pad) : min - pad;
      max += pad;
    } else {
      const pad = (max - min) * 0.12;
      min = min >= 0 ? Math.max(0, min - pad) : min - pad;
      max += pad;
    }
    const x = t => left + ((t - history.from) / (history.to - history.from)) * (w - left - right),
      y = v => top + ((max - v) / (max - min)) * (h - top - bottom);
    // The server's maxGapMs allows for collection time on top of the interval; older
    // servers only report the interval. Downsampled points also sit a bucket or two apart.
    const maxGap = Math.max(
      Number.isFinite(history.maxGapMs) ? history.maxGapMs : history.pollSeconds * 3000,
      ((history.to - history.from) / 300) * 2.5
    );
    const segments = [];
    let previous = null;
    for (const p of points) {
      if (!Number.isFinite(p.value)) {
        previous = null;
        continue;
      }
      if (!previous || p.gapBefore || p.time - previous.time > maxGap) segments.push([]);
      segments.at(-1).push(`${x(p.time).toFixed(2)} ${y(p.value).toFixed(2)}`);
      previous = p;
    }
    // A reading between two failures or gaps is a zero-length segment, which the round
    // line cap draws as a dot; a bare moveto would draw nothing.
    const line = segments
      .map(
        ([first, ...rest]) => ` M${first}${rest.length ? rest.map(p => ' L' + p).join('') : ' h0'}`
      )
      .join('');
    const ticks = Array.from({ length: 4 }, (_, i) => {
      const value = min + ((max - min) * i) / 3;
      return `<line class="chart-grid" x1="${left}" x2="${w - right}" y1="${y(value)}" y2="${y(value)}"/><text class="chart-axis" x="${left - 9}" y="${y(value) + 4}" text-anchor="end">${esc(format(value, current.unit))}</text>`;
    }).join('');
    const timeLabels = [0, 0.5, 1]
      .map(f => {
        const t = history.from + (history.to - history.from) * f;
        const label = dateTime(
          t,
          history.to - history.from > 86400000
            ? { month: 'short', day: 'numeric' }
            : { hour: '2-digit', minute: '2-digit' }
        );
        return `<text class="chart-axis" x="${x(t)}" y="${h - 5}" text-anchor="${f === 0 ? 'start' : f === 1 ? 'end' : 'middle'}">${esc(label)}</text>`;
      })
      .join('');
    chart = `<svg class="chart" data-chart="${esc(id)}" viewBox="0 0 ${w} ${h}" role="img" tabindex="0" aria-label="${esc(current.label)} history. ${valid.length} sampled reading${valid.length === 1 ? '' : 's'}. Lowest ${esc(format(Math.min(...valid.map(p => p.value)), current.unit))}, highest ${esc(format(Math.max(...valid.map(p => p.value)), current.unit))}. Collection gaps are left blank.">${ticks}${timeLabels}<path class="chart-line" d="${line}"/>${valid
      .filter((p, i) => i === valid.length - 1)
      .map(p => `<circle cx="${x(p.time)}" cy="${y(p.value)}" r="3.5" fill="var(--accent)"/>`)
      .join(
        ''
      )}</svg><p class="graph-tooltip" id="graph-tooltip">${esc(valid.length === 1 ? (history.totalSamples > 1 ? '1 sampled reading · choose a shorter range for more detail' : 'First reading saved · history builds over time') : valid.length + ' sampled readings · hover for details')}</p>`;
    const failures = history.points.filter(p => !p.ok);
    charts.set(id, { valid, failures, history, current, w, left, right });
  }
  patchHtml(
    element,
    `<div class="graph-wrap"><div class="chart-label"><label for="metric-select">Measurement</label><span>${esc(format(current.value, current.unit))}</span></div><select id="metric-select" class="metric-select">${metrics.map(m => `<option value="${esc(m.key)}" ${m.key === selectedMetric ? 'selected' : ''}>${esc(m.label)}</option>`).join('')}</select>${chart}</div><div class="detail-stats">${metrics.map(m => `<div class="stat-row"><span>${esc(m.label)}</span><strong>${esc(format(m.value, m.unit))}</strong></div>`).join('')}</div>`
  );
  $('#metric-select').value = selectedMetric;
  // Keep the tooltip on the point under a pointer that is still over the redrawn chart.
  const svg = element.querySelector('svg.chart');
  if (svg && chartPointer && svg.matches(':hover')) showChartTooltip(svg, chartPointer);
}
const hints = {
  proxmox:
    'Use a reachable Proxmox cluster address including port 8006. All node cards can share this collection address and a read-only PVEAuditor token (user@realm!token=secret). Each card can open its own node URL.',
  linux:
    'Use a node_exporter address. CPU and network rates appear after two readings. Add a separate source for each host.',
  windows:
    'Use a windows_exporter address. CPU and network rates appear after two readings. Add a separate source for each PC or server.',
  unifi:
    'Use an Integration API key, or leave it empty and use a local account with Network View Only access. A saved key takes priority. Local login needs the HTTPS console root and uses site name default when empty; API keys use site UUIDs and collect all visible sites when empty. Cloud sign-in and MFA are not supported.',
  cosmos:
    'Use the Cosmos server address and its native cosmos_ API token. Native monitoring must be enabled. Each Cosmos server has its own connection.',
  amp: 'Use a direct AMP managed-instance URL. Enter a username/password or a service login token. Controller-wide discovery is not included; add game instances separately.',
  synology:
    'Use a Prometheus exporter for your NAS, then map its numeric metrics under Advanced. This connector does not log in to DSM.',
  wireguard:
    'Use a WireGuard Prometheus exporter and map its numeric metrics under Advanced. No tunnel keys are needed by Orbit.',
  prometheus:
    'Use a Prometheus text-format exporter. Add the metric names, optional label filters, and display labels under Advanced.',
  json: 'Use a read-only JSON endpoint. Map numeric fields with dot-separated paths under Advanced.',
  docker:
    'Use a restricted Docker socket proxy that permits inventory reads. Do not expose an unrestricted Docker daemon.',
  crowdsec:
    'Use CrowdSec Local API machine credentials for alerts. Add a separate bouncer API key for decision and ban counts.',
  npm: 'Use your Nginx Proxy Manager admin address and a view-only account. Interactive MFA challenges are not supported.',
  adguard:
    'Use your AdGuard Home address and account. Your laptop-only instance must be reachable from the Orbit host.',
  tautulli:
    'Use your Tautulli address and API key. Playback statistics are collected without sending session details to your browser.',
  nzbget:
    'Use your NZBGet address and a control or restricted account with permission to read status.',
  plex: 'Use your Plex server address, normally port 32400, and a Plex token.',
  netbox:
    'Set the destination URL for quick access. To collect metrics, choose an exporter or JSON API as the Monitoring method.',
  link: 'Set a destination URL. Bookmark-only sources do not poll or generate alerts.',
  http: 'Check an HTTP or HTTPS URL without API credentials. Orbit records response time, availability and the HTTP status. Accepted redirects are not followed; a sign-in redirect only checks the front door.',
};
function field(id, label, value = '', options = {}) {
  return `<div class="field"><label for="${id}">${label}</label><input id="${id}" name="${id}" type="${options.type || 'text'}" value="${esc(value)}" ${options.required ? 'required' : ''} ${options.min !== undefined ? `min="${options.min}"` : ''} ${options.max !== undefined ? `max="${options.max}"` : ''} ${options.step ? `step="${options.step}"` : ''} ${options.maxLength ? `maxlength="${options.maxLength}"` : ''} placeholder="${esc(options.placeholder || '')}" autocomplete="${options.autocomplete || 'off'}">${options.hint ? `<small>${esc(options.hint)}</small>` : ''}</div>`;
}
function emailHasCurrentError(status = data?.notifications?.email) {
  if (!status) return false;
  if (status.state) return status.state === 'error';
  return (
    status.enabled !== false &&
    !!status.lastError &&
    (!status.lastAccepted || Number(status.lastError.time) >= Number(status.lastAccepted))
  );
}
function emailStatusText() {
  const s = data.notifications?.email;
  if (!s) return 'Email alerts are off.';
  const state = !s.enabled
    ? 'Email alerts are off.'
    : !s.configured
      ? 'Email setup is incomplete.'
      : emailHasCurrentError(s)
        ? 'Email delivery needs attention.'
        : s.lastAccepted
          ? 'Email alerts are enabled.'
          : 'Email alerts are enabled; the mail server has not accepted a message in this session yet.';
  return (
    state +
    (s.pending
      ? ` ${s.pending} message${s.pending === 1 ? ' is' : 's are'} waiting or sending.`
      : '') +
    (s.lastAccepted ? ` Last accepted by the mail server: ${dateTime(s.lastAccepted)}.` : '') +
    (s.lastError
      ? ` ${emailHasCurrentError(s) ? 'Current' : 'Previous'} delivery failure${s.lastError.time ? ' (' + dateTime(s.lastError.time) + ')' : ''}: ${s.lastError.message}`
      : '')
  );
}
function emailSettings() {
  const s = data.config.email || {
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    from: '',
    to: '',
  };
  return `<section class="config-section"><h3>Email alerts</h3><p class="settings-info">Get an email when an alert starts and when it recovers. Use a Gmail app password from your Google Account, not your normal sign-in password.</p><form id="email-form">
 ${field('email-from', 'Gmail address (sender)', s.from, { type: 'email', autocomplete: 'username' })}${field('email-to', 'Send alerts to', s.to, { type: 'email' })}
 ${field('email-password', 'Gmail app password', '', { type: 'password', autocomplete: 'new-password', placeholder: s.passwordConfigured ? 'Saved · leave blank to keep' : 'Enter an app password', hint: 'Stored privately on the Orbit server and never returned to your browser. Enter it over HTTPS.' })}
 <label class="check-row"><input id="email-enabled" type="checkbox" ${s.enabled ? 'checked' : ''}> Email alerts enabled</label>
 <label class="check-row"><input id="email-clear-password" type="checkbox"> Clear the saved app password</label>
 <details class="advanced"><summary>Mail server (Gmail defaults)</summary>${field('email-host', 'SMTP hostname', s.host)}<div class="field-row">${field('email-port', 'Port', s.port, { type: 'number', min: 1, max: 65535, required: true })}<div class="field"><label for="email-security">Encrypted connection</label><select id="email-security"><option value="tls" ${s.secure ? 'selected' : ''}>TLS · usually port 465</option><option value="starttls" ${!s.secure ? 'selected' : ''}>STARTTLS · usually port 587</option></select></div></div><p class="settings-info">Certificate verification is always required. Changing the server, connection mode or sender requires entering the app password again.</p></details>
 <div class="form-buttons"><button class="button" type="submit">Save email settings</button><button class="button" id="test-email" type="button">Send test email</button></div><p class="settings-info">Save first. A test sends one message using saved settings, even while automatic email alerts are off. Tests are limited to one per minute.</p><p id="email-status" class="settings-info">${esc(emailStatusText())}</p><p id="email-result" class="connection-test" role="status" hidden></p></form></section>`;
}
function configure(id = null, add = false) {
  if (!data) return;
  if ($('#settings-dialog').open && !allowDrawerLeave()) {
    const picker = $('#source-picker');
    if (picker) picker.value = settingsId || '';
    return;
  }
  const nextId = add ? null : id || data.config.services[0]?.id || null;
  const s = nextId
    ? data.config.services.find(s => s.id === nextId)
    : {
        type: 'cosmos',
        name: '',
        group: 'Utilities',
        enabled: true,
        url: '',
        apiUrl: '',
        username: '',
        collector: 'native',
        metrics: [],
        rules: [],
      };
  if (!s) {
    // Removed on another device or tab after this page was drawn.
    const picker = $('#source-picker');
    if (picker) picker.value = settingsId || '';
    toast('This source no longer exists. It may have been removed on another device.');
    load();
    return;
  }
  testController?.abort();
  settingsId = nextId;
  drawerRevision = data.config.revision;
  draftRules = structuredClone(s.rules || []);
  editingRule = null;
  draftCredentials = {};
  $('#settings-content').innerHTML =
    `<div class="connection-picker"><div class="field"><label for="source-picker">Source</label><select id="source-picker">${!settingsId ? '<option value="">New source</option>' : ''}${data.config.services.map(c => `<option value="${esc(c.id)}" ${c.id === settingsId ? 'selected' : ''}>${esc(c.name)}${c.enabled ? '' : ' · paused'}</option>`).join('')}</select></div><button class="button add-source" data-add-source aria-label="Add another source">${icon('plus', 18)}</button></div>
 <form id="connection-form"><div class="field"><label for="source-type">Service type</label><select id="source-type" ${settingsId ? 'disabled' : ''}>${data.catalog.map(c => `<option value="${c.type}" ${c.type === s.type ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
 <div id="type-hint" class="settings-hint">${esc(hints[s.type] || 'Use the application address and its API key. Credentials stay on the Orbit server.')}</div>
 ${field('source-name', 'Display name', s.name, { required: true, placeholder: 'e.g. Cosmos · media' })}
 <div class="field-row">${field('source-group', 'Group', s.group, { required: true })}<div class="field"><label for="source-color">Accent</label><select id="source-color">${['violet', 'cyan', 'blue', 'orange', 'amber', 'pink', 'green'].map(c => `<option ${c === (s.color || 'violet') ? 'selected' : ''} value="${c}">${c[0].toUpperCase() + c.slice(1)}</option>`).join('')}</select></div></div>
 ${field('source-url', 'Open this URL when clicked', s.url, { type: 'url', placeholder: 'https://service.your-domain' })}
 ${selectField('source-collector', 'Monitoring method', s.collector || 'native', [
   ['native', 'Default for this service'],
   ['http', 'Website check'],
   ['linux', 'Linux node_exporter'],
   ['windows', 'Windows exporter'],
   ['prometheus', 'Custom Prometheus exporter'],
   ['json', 'Custom JSON API'],
   ['none', 'Bookmark only'],
 ])}
 <div id="endpoint-fields">${field('source-api', 'Collect measurements from', s.apiUrl, { type: 'url', placeholder: 'https://internal-address:port', hint: 'May be different from the address you open in your browser.' })}</div>
 <div id="http-fields" hidden><div class="field-row">${selectField(
   'source-http-method',
   'Request method',
   s.httpMethod || 'GET',
   [
     ['GET', 'GET · check the response'],
     ['HEAD', 'HEAD · headers only'],
   ]
 )}${field('source-http-status', 'Accepted HTTP statuses', s.httpExpectedStatus || '200-399', { maxLength: 256, placeholder: '200-399', hint: 'Codes or ranges separated by commas. Add 401 or 403 only if an authentication response is expected.' })}</div><p class="settings-info">The default accepts successful responses and redirects. Redirects are not followed, so a login redirect checks the front door. HEAD uses less data, but some services only support GET. Checks the initial response, not page assets. Saved API credentials are not sent.</p></div>
 <div id="proxmox-fields" ${s.type === 'proxmox' ? '' : 'hidden'}>${field('source-node', 'Proxmox node name (optional)', s.nodeName || '', { maxLength: 63, placeholder: 'e.g. Proxmox-1', hint: 'Leave blank for the whole cluster. Enter the exact, case-sensitive node name for a single host. Native Proxmox collection only.' })}</div>
 <div id="credential-fields"></div><div id="credential-clear"></div>
 <label class="check-row"><input id="source-enabled" type="checkbox" ${s.enabled ? 'checked' : ''}> Monitoring enabled <span class="muted">· turn off while this server is stopped</span></label>
 <label class="check-row"><input id="source-visible" type="checkbox" ${s.showOnDashboard !== false ? 'checked' : ''}> Show this source on the dashboard</label>${field('source-poll', 'Collection interval (seconds)', s.pollSeconds || 0, { type: 'number', min: 0, max: 3600, step: 1, required: true, hint: `0 uses the workspace default (${data.config.pollSeconds}s). Otherwise choose 15–3600 seconds. Hiding a card does not pause collection.` })}<details class="advanced" id="connection-advanced"><summary>Advanced connection settings</summary>
 <div id="metric-path-field">${field('metric-path', 'Custom endpoint path', s.metricPath || '', { placeholder: '/metrics', hint: 'Optional path appended to the collection address.' })}</div>
 <div id="site-fields">${field('site-id', 'UniFi site UUID or local site name (optional)', s.siteId || '', { hint: 'API key: site UUID, or all sites when empty. Local account: site name, usually default.' })}</div>
 <div class="field" id="mapping-fields"><label for="metric-mappings">Custom metric mappings (JSON)</label><textarea id="metric-mappings" rows="6" spellcheck="false" placeholder='[{"key":"cpu","label":"CPU","path":"system.cpu","unit":"%"}]'>${esc(JSON.stringify(s.metrics || [], null, 2))}</textarea><small>JSON: dot-separated field paths. Exporters: metric names, optional labels, and scale. No credentials here.</small></div></details>
 <div class="connection-test-actions"><button class="button" id="test-connection" type="button">Test connection</button><small>Checks these settings with the selected retry policy, without saving history or creating alerts.</small></div><div id="connection-test" class="connection-test" role="status" hidden></div>
 ${sourceAlertSettings(s)}
 <section class="config-section"><h3>Metric thresholds</h3><p class="settings-info">These warnings describe measurements, not whether the service is reachable. A separate recovery boundary can prevent repeated alerts when a value hovers near a limit. Add or update a rule before saving this connection.</p><div id="rule-list"></div><div class="rule-builder"><div class="field"><label for="rule-key">Measurement</label><input id="rule-key" list="metric-options" placeholder="Select or enter a metric key"><datalist id="metric-options">${(stateFor(s.id).metrics || []).map(m => `<option value="${esc(m.key)}">${esc(m.label)} (${esc(m.unit || 'count')})</option>`).join('')}</datalist></div><div class="field-row"><div class="field"><label for="rule-operator">Condition</label><select id="rule-operator"><option value="gt">Above</option><option value="lt">Below</option></select></div>${field('rule-threshold', 'Threshold', '', { type: 'number', step: 'any' })}</div>${field('rule-duration', 'Sustained for (seconds)', '120', { type: 'number', min: 0, max: 86400 })}${field('rule-recovery', 'Recovery boundary (optional)', '', { type: 'number', step: 'any', hint: 'Blank uses the alert threshold. Example: memory above 90% alerts, then 88% or below confirms recovery.' })}<div class="rule-editor-actions"><button class="button" id="add-rule" type="button">${icon('plus', 14)} Add rule</button><button class="quiet-button" id="cancel-rule-edit" type="button" hidden>Cancel edit</button></div></div></section>
 <p class="field-error" id="form-error" role="alert" hidden></p><div class="form-buttons"><button class="button primary" type="submit">${settingsId ? 'Save connection' : 'Add source'}</button>${settingsId ? '<button class="quiet-button danger" id="delete-source" type="button">Remove source</button>' : ''}</div></form>
`;
  renderCredentials(s);
  renderMonitoringMethod();
  renderRules();
  drawerBaseline = formSnapshot($('#connection-form'));
  drawerRulesBaseline = JSON.stringify(draftRules);
  if (!$('#settings-dialog').open) $('#settings-dialog').showModal();
}
function renderCredentials(s) {
  for (const key of ['username', 'password', 'key']) {
    const field = $('#source-' + key);
    if (field) draftCredentials[key] = field.value;
  }
  if ($('#clear-credentials')) draftCredentials.clear = $('#clear-credentials').checked;
  const mode = $('#source-collector')?.value;
  if (mode && mode !== 'native') s = { ...s, type: mode };
  const passwordTypes = ['amp', 'adguard', 'nzbget', 'npm', 'crowdsec', 'unifi'];
  const keyTypes = [
    'proxmox',
    'cosmos',
    'amp',
    'unifi',
    'plex',
    'tautulli',
    'sonarr',
    'radarr',
    'prowlarr',
    'seerr',
    'sabnzbd',
    'crowdsec',
    'prometheus',
    'json',
    'linux',
    'windows',
    'synology',
    'wireguard',
  ];
  $('#credential-fields').innerHTML =
    (passwordTypes.includes(s.type)
      ? field(
          'source-username',
          s.type === 'crowdsec'
            ? 'Machine ID'
            : s.type === 'unifi'
              ? 'Local Network View Only username'
              : 'Username',
          s.username || ''
        ) +
        field('source-password', 'Password', '', {
          type: 'password',
          autocomplete: 'new-password',
          placeholder: s.passwordConfigured ? 'Saved · leave blank to keep' : 'Password',
        })
      : '') +
    (keyTypes.includes(s.type)
      ? field(
          'source-key',
          s.type === 'crowdsec'
            ? 'Bouncer API key (optional)'
            : s.type === 'amp'
              ? 'Service login token (optional)'
              : s.type === 'unifi'
                ? 'Integration API key (optional; takes priority)'
                : s.type === 'proxmox'
                  ? 'API token ID and secret'
                  : 'API key / token',
          '',
          {
            type: 'password',
            autocomplete: 'new-password',
            placeholder: s.apiKeyConfigured ? 'Saved · leave blank to keep' : 'Token',
            hint: 'Saved credentials are never returned to your browser.',
          }
        )
      : '');
  // Kept outside #credential-fields so it stays available in Website check and Bookmark
  // modes, which hide the credential inputs but may still hold saved secrets.
  const inputs = !!$('#credential-fields').innerHTML;
  $('#credential-clear').innerHTML =
    s.apiKeyConfigured || s.passwordConfigured
      ? `<label class="check-row"><input id="clear-credentials" type="checkbox"> Clear saved credentials <span class="muted">· ${inputs ? 'keeps any you enter above' : 'this monitoring method does not use them'}</span></label>`
      : '';
  for (const key of ['username', 'password', 'key'])
    if (draftCredentials[key] !== undefined && $('#source-' + key))
      $('#source-' + key).value = draftCredentials[key];
  if ($('#clear-credentials') && draftCredentials.clear !== undefined)
    $('#clear-credentials').checked = draftCredentials.clear;
}
function renderMonitoringMethod() {
  const type = $('#source-type').value,
    chosen = $('#source-collector').value,
    method =
      chosen === 'native'
        ? type === 'http'
          ? 'http'
          : type === 'link' || type === 'netbox'
            ? 'none'
            : type
        : chosen,
    website = method === 'http',
    bookmark = method === 'none';
  $('#type-hint').textContent =
    hints[chosen === 'none' ? 'link' : method] ||
    hints[type] ||
    'Use the application address and its API key. Credentials stay on the Orbit server.';
  // Hidden sections are disabled too: the browser then skips their validation instead of
  // silently blocking Save, and connectionInput() leaves their saved values alone.
  const show = (selector, visible) => {
    const section = $(selector);
    section.hidden = !visible;
    for (const control of section.querySelectorAll('input,select,textarea'))
      control.disabled = !visible;
  };
  show('#http-fields', website);
  show('#endpoint-fields', !bookmark);
  show('#credential-fields', !website && !bookmark);
  show('#proxmox-fields', type === 'proxmox' && chosen === 'native');
  show('#site-fields', type === 'unifi' && chosen === 'native');
  // Only the exporter and JSON collectors read mappings and a custom path (plus the path of
  // a Website check); native integrations use fixed endpoints and would ignore them.
  const mapped = ['linux', 'windows', 'synology', 'wireguard', 'prometheus', 'json'].includes(
    method
  );
  show('#mapping-fields', mapped);
  show('#metric-path-field', mapped || website);
  $('label[for="source-api"]').textContent = website
    ? 'Website URL to check'
    : 'Collect measurements from';
  $('#endpoint-fields small').textContent = website
    ? 'Leave blank to check the URL opened by this card. Use the full HTTP or HTTPS address, with no embedded credentials.'
    : 'May be different from the address you open in your browser.';
  $('#connection-advanced').hidden = !(
    mapped ||
    website ||
    (type === 'unifi' && chosen === 'native')
  );
  $('#connection-advanced summary').textContent = website
    ? 'Optional website path'
    : 'Advanced connection settings';
  $('label[for="metric-path"]').textContent = website
    ? 'Optional check path'
    : 'Custom endpoint path';
  $('#metric-path-field small').textContent = website
    ? 'Appended to the URL above. Usually blank. Clear an old /metrics or API path to check the website root.'
    : 'Optional path appended to the collection address.';
  if (website && $('#metric-path').value) $('#connection-advanced').open = true;
}
const monitoringFields = [
  ['retryCount', 'Extra attempts', 0, 3, 2],
  ['retryDelaySeconds', 'Delay between retries (seconds)', 1, 30, 2],
  ['timeoutSeconds', 'Total collection deadline (seconds)', 5, 120, 90],
  ['availabilityFailures', 'Failed checks before alerting', 1, 10, 2],
  ['availabilitySeconds', 'Failure grace (seconds)', 0, 3600, 60],
  ['recoverySuccesses', 'Healthy checks before recovery', 1, 10, 2],
  ['recoverySeconds', 'Recovery grace (seconds)', 0, 3600, 60],
];
function sourceAlertSettings(s) {
  const monitoring = s.monitoring || {},
    alerts = s.alerts || {},
    global = data.config.alerts || {},
    overrides = Object.values(monitoring).filter(v => v !== null && v !== undefined).length;
  const preference = (key, label) =>
    selectField(
      'source-alert-' + key,
      label,
      alerts[key] === true ? 'true' : alerts[key] === false ? 'false' : 'inherit',
      [
        ['inherit', `Workspace default · ${global[key] === false ? 'muted' : 'send'}`],
        ['true', 'Send notifications'],
        ['false', 'Mute notifications'],
      ]
    );
  return `<section class="config-section"><h3>Notifications for this source</h3><p class="settings-info">Choose which kinds of warnings send email or webhooks. Active warnings and history remain visible; the workspace alert/recovery delivery switches still apply.</p><div class="field-row">${preference('notifyAvailability', 'Connection notifications')}${preference('notifyMeasurements', 'Metric notifications')}</div><details class="advanced retry-overrides" ${overrides ? 'open' : ''}><summary>Retry & confirmation overrides <span class="muted">${overrides ? '· ' + overrides + ' custom' : '· using workspace defaults'}</span></summary><p class="settings-info">Leave a field blank to inherit its workspace value. Zero is an explicit setting where allowed. Retries belong to one completed check; they do not count as extra alert confirmations.</p><div class="field-row">${monitoringFields.map(([key, label, min, max, fallback]) => field('source-monitoring-' + key, label, monitoring[key] ?? '', { type: 'number', min, max, step: 1, placeholder: `Workspace: ${data.config.monitoring?.[key] ?? fallback}`, hint: `Workspace default: ${data.config.monitoring?.[key] ?? fallback}. Allowed: ${min}–${max}.` })).join('')}</div><p class="settings-info">The collection deadline includes all attempts and retry delays. Recovery needs consecutive successful checks plus its grace period; metric readings must also reach their recovery boundary. Rejected logins and invalid-response errors are not retried.</p></details></section>`;
}
function renderRules() {
  $('#rule-list').innerHTML = draftRules
    .map(
      (r, i) =>
        `<div class="rule ${editingRule === i ? 'editing' : ''}"><span><strong>${esc(r.key)}</strong> ${r.operator === 'gt' ? 'above' : 'below'} ${esc(r.threshold)} <small>for ${r.forSeconds}s${r.recoveryThreshold !== undefined && r.recoveryThreshold !== null ? ` · recover at ${esc(r.recoveryThreshold)} or ${r.operator === 'gt' ? 'below' : 'above'}` : ''}</small></span><div class="rule-actions"><button type="button" class="quiet-button" data-edit-rule="${i}" aria-label="Edit rule for ${esc(r.key)}">Edit</button><button type="button" class="icon-button" data-remove-rule="${i}" aria-label="Remove rule for ${esc(r.key)}">×</button></div></div>`
    )
    .join('');
}
function clearRuleEditor() {
  editingRule = null;
  $('#rule-key').value = '';
  $('#rule-threshold').value = '';
  $('#rule-recovery').value = '';
  $('#rule-duration').value = '120';
  $('#rule-operator').value = 'gt';
  $('#add-rule').innerHTML = icon('plus', 14) + ' Add rule';
  $('#cancel-rule-edit').hidden = true;
  renderRules();
}
function renderAlerts() {
  const active = data.alerts
    .map(
      a =>
        `<div class="alert-row"><span class="alert-kind">${a.rule === '__availability' ? 'Connection check' : 'Metric threshold'}</span><strong>${esc(a.name)}</strong><p>${esc(a.message)}</p><small>Since ${dateTime(a.since)}</small></div>`
    )
    .join('');
  const events = (data.events || [])
    .slice(0, 12)
    .map(
      e =>
        `<div class="event-row"><span class="${e.kind === 'resolved' ? 'resolved' : 'firing'}">${e.kind === 'resolved' ? 'Resolved' : 'Alert'}</span><div><strong>${esc(e.name)}</strong><p>${esc(e.message)}</p></div><time>${when(e.time)}</time></div>`
    )
    .join('');
  $('#alerts-content').innerHTML =
    (active
      ? '<p class="settings-info">A connection alert means Orbit could not complete its check. A metric alert means a reported measurement crossed its threshold; the service may still be reachable.</p>'
      : '') +
    (active ||
      `<div class="empty-history"><div class="empty-symbol">${icon('check', 25)}</div><h4>No active alerts</h4><p>${data.services.some(s => s.configured) ? 'Enabled sources are checked in the background. Paused sources do not generate alerts.' : 'Connect your sources to begin monitoring, then set thresholds for the measurements that matter.'}</p></div>`) +
    (data.notifications?.lastError
      ? '<p class="detail-error">Webhook delivery failed. These in-app alerts remain available.</p>'
      : '') +
    (emailHasCurrentError()
      ? `<p class="detail-error">${esc(data.notifications.email.lastError?.message || 'Email delivery needs attention.')} These in-app alerts remain available.</p>`
      : '') +
    (events ? `<section class="config-section"><h3>Recent activity</h3>${events}</section>` : '');
}
function emailInput() {
  const input = {
    enabled: $('#email-enabled').checked,
    host: $('#email-host').value,
    port: Number($('#email-port').value),
    secure: $('#email-security').value === 'tls',
    from: $('#email-from').value,
    to: $('#email-to').value,
  };
  if ($('#email-password').value) input.password = $('#email-password').value;
  if ($('#email-clear-password').checked) input.clearPassword = true;
  return input;
}
async function emailAction(test = false) {
  const form = $('#email-form');
  if (!form.reportValidity()) return;
  const result = $('#email-result');
  let unlock = () => {};
  result.hidden = false;
  result.className = 'connection-test';
  try {
    const input = emailInput(),
      saved = data.config.email;
    if (
      test &&
      (input.password || input.clearPassword || Object.keys(input).some(k => input[k] !== saved[k]))
    )
      throw new Error('Save email settings before sending a test.');
    unlock = lockForm(form);
    result.textContent = test ? 'Sending one test email…' : 'Saving email settings…';
    if (test) {
      const response = await api('/api/email/test', { method: 'POST', body: '{}' });
      result.textContent = response.message;
      await load();
    } else {
      const response = await writeConfig(
        '/api/settings',
        { method: 'PATCH', body: JSON.stringify({ email: input }) },
        {
          revision: () => pageRevision,
          apply: config => {
            // The app password itself is never returned, only whether one is saved.
            const { password, clearPassword, ...saved } = input;
            config.email = {
              ...config.email,
              ...saved,
              passwordConfigured: clearPassword
                ? false
                : password
                  ? true
                  : !!config.email?.passwordConfigured,
            };
          },
        }
      );
      pageRevision = response.revision ?? pageRevision;
      $('#email-password').value = '';
      $('#email-clear-password').checked = false;
      result.textContent = 'Email settings saved.';
      // Show the values as saved (the server trims and lowercases the host), so the
      // test-email check below compares like with like.
      if (await load())
        for (const key of ['host', 'port', 'from', 'to'])
          $('#email-' + key).value = data.config.email[key];
      pageBaseline = formSnapshot(form);
      updateDirtyIndicator();
    }
    $('#email-password').placeholder = data.config.email.passwordConfigured
      ? 'Saved · leave blank to keep'
      : 'Enter an app password';
    $('#email-status').textContent = emailStatusText();
    result.classList.add('success');
  } catch (error) {
    result.classList.add('failed');
    result.textContent =
      !test && error.status === 409
        ? `${conflictMessage} Choose Discard unsaved changes to load the latest settings.`
        : error.message;
    await load();
    if ($('#email-status')) $('#email-status').textContent = emailStatusText();
  } finally {
    unlock();
  }
}
async function toggleSource(id) {
  const s = data.config.services.find(s => s.id === id);
  if (!s) return;
  try {
    await writeConfig(
      `/api/services/${id}`,
      { method: 'PATCH', body: JSON.stringify({ enabled: !s.enabled }) },
      { revision: () => data.config.revision, apply: replaceService, source: id }
    );
    // The chart shows the pause gap, and the first reading after a resume, at once.
    if (id === expanded) refreshHistory(id);
    await load();
    toast(s.enabled ? `${s.name} paused. Settings and history are saved.` : `${s.name} resumed.`);
  } catch (e) {
    toast(e.status === 409 ? `${conflictMessage} The latest settings are shown now.` : e.message);
    if (e.status === 409) await load();
  }
}
/** An unadded rule would otherwise be dropped silently when the connection is saved. */
function ruleDraftPending() {
  return (
    editingRule === null &&
    ['#rule-key', '#rule-threshold', '#rule-recovery'].some(
      id => $(id)?.value.trim() || $(id)?.validity.badInput
    )
  );
}
/** The draft stays in the drawer; replacing it with the latest settings is the user's call. */
async function showDrawerConflict() {
  $('#form-error').hidden = false;
  $('#form-error').innerHTML =
    `${esc(conflictMessage)} <button class="quiet-button" type="button" data-reload-source>Discard my edits and load the latest</button>`;
  await load();
}
function resetTestButton() {
  const button = $('#test-connection');
  if (!button) return;
  button.disabled = false;
  button.textContent = 'Test connection';
}
function connectionInput() {
  if (editingRule !== null)
    throw new Error(
      'Update the edited rule or cancel its edit before saving or testing this connection.'
    );
  const poll = Number($('#source-poll').value);
  if (!Number.isInteger(poll) || poll < 0 || poll > 3600 || (poll > 0 && poll < 15))
    throw new Error('Choose 0 for the default interval, or 15–3600 seconds.');
  // Fields in sections this monitoring method hides stay undefined, which omits them from
  // the request so the server keeps their saved values. (Not `disabled`: lockForm() sets
  // that on every control while saving.)
  const shown = id => {
    const control = $('#' + id);
    return control && !control.closest('[hidden]') ? control.value : undefined;
  };
  const input = {
    type: $('#source-type').value,
    name: $('#source-name').value,
    group: $('#source-group').value,
    color: $('#source-color').value,
    url: $('#source-url').value,
    apiUrl: shown('source-api'),
    enabled: $('#source-enabled').checked,
    showOnDashboard: $('#source-visible').checked,
    pollSeconds: Number($('#source-poll').value),
    collector: $('#source-collector').value,
    metricPath: shown('metric-path'),
    siteId: shown('site-id'),
    nodeName: shown('source-node'),
    httpMethod: shown('source-http-method'),
    httpExpectedStatus: shown('source-http-status'),
    username: shown('source-username'),
    // A typed key or password is kept even when 'Clear saved credentials' is ticked.
    apiKey: shown('source-key') || undefined,
    password: shown('source-password') || undefined,
    monitoring: Object.fromEntries(
      monitoringFields.map(([key]) => [
        key,
        $('#source-monitoring-' + key).value.trim() === ''
          ? null
          : Number($('#source-monitoring-' + key).value),
      ])
    ),
    alerts: Object.fromEntries(
      ['notifyAvailability', 'notifyMeasurements'].map(key => [
        key,
        $('#source-alert-' + key).value === 'inherit'
          ? null
          : $('#source-alert-' + key).value === 'true',
      ])
    ),
    rules: draftRules,
  };
  if (input.httpExpectedStatus === '') input.httpExpectedStatus = '200-399';
  if ($('#clear-credentials')?.checked) {
    input.apiKey ??= '';
    input.password ??= '';
  }
  const mappings = shown('metric-mappings');
  if (mappings !== undefined) {
    try {
      input.metrics = JSON.parse(mappings || '[]');
    } catch {
      throw new Error('Metric mappings must contain valid JSON.');
    }
  }
  return input;
}
async function testConnection() {
  const form = $('#connection-form');
  if (!form.reportValidity()) return;
  testController?.abort();
  const controller = new AbortController();
  testController = controller;
  const button = $('#test-connection'),
    result = $('#connection-test');
  button.disabled = true;
  button.textContent = 'Testing…';
  result.hidden = false;
  result.className = 'connection-test';
  result.textContent = 'Connecting and checking available measurements…';
  try {
    const response = await api('/api/test-service', {
      method: 'POST',
      body: JSON.stringify({ serviceId: settingsId, settings: connectionInput() }),
      signal: controller.signal,
    });
    if (controller.signal.aborted) return;
    result.classList.add('success');
    const website = response.metrics.some(m => m.key === 'http_status');
    result.innerHTML = `<strong>Connected · ${response.metrics.length} measurements</strong><p>${response.metrics
      .slice(0, 4)
      .map(m => `${esc(m.label)}: ${esc(format(m.value, m.unit))}`)
      .join(
        ' · '
      )}</p><small>Test completed in ${(response.elapsedMs / 1000).toFixed(1)}s. Save the connection when you’re ready. ${website ? 'The HTTP status matches your accepted statuses. Redirects are not followed.' : 'CPU and network rates may need two scheduled readings.'}${response.credentialsCleared ? ' Saving will clear the saved credentials: this method does not use them, and Orbit never sends them to a new address.' : ''}</small>`;
    $('#metric-options').innerHTML = response.metrics
      .map(
        m => `<option value="${esc(m.key)}">${esc(m.label)} (${esc(m.unit || 'count')})</option>`
      )
      .join('');
  } catch (e) {
    if (controller.signal.aborted) return;
    result.classList.add('failed');
    result.textContent = e.message;
  } finally {
    // A newer test, or a save that locked the form, owns the button now.
    if (testController === controller && busyForm !== form) resetTestButton();
  }
}
async function submitConnection(form) {
  testController?.abort();
  // Reset now: the aborted test settles later, and lockForm() must not record its
  // disabled button, or a failed save would restore it disabled.
  resetTestButton();
  const unlock = lockForm(form);
  try {
    if (ruleDraftPending())
      throw new Error(
        'Add the rule you started with Add rule, or clear its fields, before saving this connection.'
      );
    const input = connectionInput(),
      id = settingsId;
    const result = await writeConfig(
      id ? `/api/services/${id}` : '/api/services',
      { method: id ? 'PATCH' : 'POST', body: JSON.stringify(input) },
      id
        ? { revision: () => drawerRevision, apply: replaceService, source: id }
        : {
            // A new source is added to the configuration as this tab has it.
            revision: () => data.config.revision,
            apply: (config, { service }) => (config.services = [...config.services, service]),
            conditional: false,
          }
    );
    if (id && id === expanded) refreshHistory(id);
    drawerBaseline = '';
    $('#settings-dialog').close();
    await load();
    toast(
      `${result.service.name} saved${result.service.enabled ? '' : ' · monitoring paused'}${result.credentialsCleared ? ' · saved credentials cleared for the new address' : ''}`
    );
  } catch (e) {
    if (e.status === 409) await showDrawerConflict();
    else {
      $('#form-error').hidden = false;
      $('#form-error').textContent = e.message;
    }
  } finally {
    unlock();
  }
}
document.addEventListener('click', async e => {
  if (e.target.closest('#test-email')) {
    await emailAction(true);
    return;
  }
  if (e.target.closest('#test-connection')) {
    await testConnection();
    return;
  }
  const expand = e.target.closest('[data-expand]');
  if (expand) {
    expanded = expanded === expand.dataset.expand ? null : expand.dataset.expand;
    selectedMetric = '';
    forgetHistory();
    render();
    if (expanded) await loadHistory(expanded);
    return;
  }
  if (e.target.closest('[data-reload-source]')) {
    drawerBaseline = '';
    configure(settingsId);
    return;
  }
  const config = e.target.closest('[data-configure]');
  if (config) {
    configure(config.dataset.configure);
    return;
  }
  if (e.target.closest('[data-add-source]')) {
    configure(null, true);
    return;
  }
  const toggle = e.target.closest('[data-toggle]');
  if (toggle) {
    await toggleSource(toggle.dataset.toggle);
    return;
  }
  const r = e.target.closest('[data-range]');
  if (r) {
    range = r.dataset.range;
    render();
    await loadHistory(expanded);
    $(`[data-range="${range}"]`)?.focus({ preventScroll: true });
    return;
  }
  const edit = e.target.closest('[data-edit-rule]');
  if (edit) {
    editingRule = Number(edit.dataset.editRule);
    const rule = draftRules[editingRule];
    $('#rule-key').value = rule.key;
    $('#rule-operator').value = rule.operator;
    $('#rule-threshold').value = rule.threshold;
    $('#rule-duration').value = rule.forSeconds;
    $('#rule-recovery').value = rule.recoveryThreshold ?? '';
    $('#add-rule').textContent = 'Update rule';
    $('#cancel-rule-edit').hidden = false;
    renderRules();
    $('#rule-recovery').focus();
    return;
  }
  if (e.target.closest('#cancel-rule-edit')) {
    clearRuleEditor();
    return;
  }
  const remove = e.target.closest('[data-remove-rule]');
  if (remove) {
    const index = Number(remove.dataset.removeRule);
    draftRules.splice(index, 1);
    if (editingRule === index) clearRuleEditor();
    else {
      if (editingRule !== null && editingRule > index) editingRule--;
      renderRules();
    }
    return;
  }
  if (e.target.closest('#add-rule')) {
    const key = $('#rule-key').value.trim(),
      threshold = Number($('#rule-threshold').value),
      forSeconds = Number($('#rule-duration').value),
      operator = $('#rule-operator').value,
      recoveryText = $('#rule-recovery').value.trim(),
      recovery = recoveryText === '' ? null : Number(recoveryText);
    // A number input reports '' for text it cannot parse (e.g. '2m' or '88%'), and
    // Number('') is 0, so check for blank and unreadable input before converting.
    if ($('#rule-threshold').validity.badInput) {
      toast('Enter the threshold as a number.');
      return;
    }
    if ($('#rule-duration').value.trim() === '' || $('#rule-duration').validity.badInput) {
      toast('Enter how long the condition must last, in whole seconds (0–86400).');
      return;
    }
    if ($('#rule-recovery').validity.badInput) {
      toast('Enter the recovery boundary as a number, or leave it blank.');
      return;
    }
    if (
      !key ||
      $('#rule-threshold').value === '' ||
      !Number.isFinite(threshold) ||
      !Number.isInteger(forSeconds) ||
      forSeconds < 0 ||
      forSeconds > 86400
    ) {
      toast('Choose a measurement, threshold, and valid duration.');
      return;
    }
    if (
      recovery !== null &&
      (!Number.isFinite(recovery) ||
        (operator === 'gt' ? recovery > threshold : recovery < threshold))
    ) {
      toast(
        operator === 'gt'
          ? 'Recovery must be at or below the alert threshold.'
          : 'Recovery must be at or above the alert threshold.'
      );
      return;
    }
    if (draftRules.some((r, i) => r.key === key && i !== editingRule)) {
      toast('This measurement already has a rule.');
      return;
    }
    const rule = {
      key,
      threshold,
      forSeconds,
      operator,
      ...(recovery !== null ? { recoveryThreshold: recovery } : {}),
    };
    if (editingRule === null) draftRules.push(rule);
    else draftRules[editingRule] = rule;
    clearRuleEditor();
    return;
  }
  if (e.target.closest('#delete-source')) {
    const s = data.config.services.find(s => s.id === settingsId);
    if (confirm(`Remove ${s.name} and its saved history? Pause it instead to keep everything.`)) {
      try {
        const id = settingsId;
        await writeConfig(
          `/api/services/${id}`,
          { method: 'DELETE', body: '{}' },
          {
            revision: () => drawerRevision,
            apply: config => (config.services = config.services.filter(s => s.id !== id)),
            source: id,
          }
        );
        drawerBaseline = '';
        $('#settings-dialog').close();
        if (expanded === settingsId) expanded = null;
        forgetHistory();
        await load();
        toast('Source removed.');
      } catch (error) {
        if (error.status === 409) await showDrawerConflict();
        else toast(error.message);
      }
    }
  }
});
function clearConnectionTest(e) {
  if (e.target.closest('#connection-form')) {
    testController?.abort();
    const result = $('#connection-test');
    if (result) result.hidden = true;
  }
}
document.addEventListener('input', clearConnectionTest);
// The browser cannot point at an invalid field inside a closed <details>, so it would
// cancel Save or Test without a message. Open it first ('invalid' does not bubble).
document.addEventListener(
  'invalid',
  e => {
    const details = e.target.closest('details');
    if (details) details.open = true;
  },
  true
);
document.addEventListener('change', e => {
  clearConnectionTest(e);
  if (e.target.id === 'email-security' && ['465', '587'].includes($('#email-port').value))
    $('#email-port').value = e.target.value === 'tls' ? '465' : '587';
  if (e.target.id === 'metric-select') {
    selectedMetric = e.target.value;
    renderGraph(expanded);
    $('#metric-select').focus({ preventScroll: true });
  }
  if (e.target.id === 'source-picker') configure(e.target.value, !e.target.value);
  if (e.target.id === 'source-collector') {
    const saved = data.config.services.find(s => s.id === settingsId) || {
      type: $('#source-type').value,
    };
    renderCredentials({ ...saved, type: $('#source-type').value });
    renderMonitoringMethod();
  }
  if (e.target.id === 'source-type') {
    const type = e.target.value,
      def = data.catalog.find(c => c.type === type);
    $('#source-group').value = def.group;
    $('#source-color').value = def.color;
    renderCredentials({ type });
    renderMonitoringMethod();
  }
});
document.addEventListener('submit', async e => {
  if (e.target.id === 'email-form') {
    e.preventDefault();
    await emailAction();
  }
  if (e.target.id === 'connection-form') {
    e.preventDefault();
    await submitConnection(e.target);
  }
});
// Enter in a rule field adds the rule instead of submitting (and saving) the whole form.
document.addEventListener('keydown', e => {
  if (e.key !== 'Enter' || e.isComposing || !e.target.closest?.('.rule-builder')) return;
  if (e.target.matches('button')) return;
  e.preventDefault();
  const missing = ['#rule-key', '#rule-threshold']
    .map(id => $(id))
    .find(field => !field.value.trim() && !field.validity.badInput);
  if (missing) missing.focus();
  else $('#add-rule').click();
});
document.addEventListener('pointermove', e => {
  const svg = e.target.closest('[data-chart]');
  chartPointer = svg ? { clientX: e.clientX, clientY: e.clientY } : null;
  if (svg) showChartTooltip(svg, e);
});
function showChartTooltip(svg, { clientX, clientY }) {
  const chart = charts.get(svg.dataset.chart),
    matrix = svg.getScreenCTM();
  if (!chart || !matrix) return;
  // Map through the SVG's own transform, which includes any scaling or letterboxing.
  const vx = new DOMPoint(clientX, clientY).matrixTransform(matrix.inverse()).x;
  const t =
    chart.history.from +
    ((vx - chart.left) / (chart.w - chart.left - chart.right)) *
      (chart.history.to - chart.history.from);
  const closest = list =>
    list.reduce((a, b) => (Math.abs(b.time - t) < Math.abs(a.time - t) ? b : a));
  const nearest = closest(chart.valid),
    failure = chart.failures?.length ? closest(chart.failures) : null;
  const tip = $('#graph-tooltip');
  if (!tip) return;
  // A failed collection closer to the pointer than any reading shows why it failed.
  tip.textContent =
    failure && Math.abs(failure.time - t) < Math.abs(nearest.time - t)
      ? failure.gap
        ? `${dateTime(failure.time)} · No collection (paused or reconfigured)`
        : `${dateTime(failure.time)} · Collection failed${failure.error ? ': ' + failure.error : ''}`
      : `${dateTime(nearest.time)} · ${format(nearest.value, chart.current.unit)}`;
}
$('#settings-dialog').addEventListener('close', () => testController?.abort());
$('#settings').onclick = () => navigate(configurationSection ? '#' : '#configure/overview');
$('#add-source').onclick = () => configure(null, true);
$('#collapse-all').onclick = () => {
  expanded = null;
  forgetHistory();
  render();
};
$('#refresh').onclick = async () => {
  try {
    await api('/api/refresh', { method: 'POST', body: '{}' });
    toast('Refreshing enabled sources…');
    if (expanded) refreshHistory(expanded);
    await load();
    setTimeout(load, 2000);
  } catch (e) {
    toast(e.message);
  }
};
$('#alerts-button').onclick = () => {
  if (!data) return;
  renderAlerts();
  $('#alerts-dialog').showModal();
};
let resizeFrame;
window.addEventListener('resize', () => {
  cancelAnimationFrame(resizeFrame);
  resizeFrame = requestAnimationFrame(() => {
    if (expanded) renderGraph(expanded);
  });
});
function clock() {
  $('#clock').textContent = dateTime(Date.now(), {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

const configurationSections = [
  ['overview', 'Overview', 'orbit', 'A clear view of your workspace.'],
  ['appearance', 'Appearance', 'grid', 'Make Orbit feel like home.'],
  ['sources', 'Sources', 'layers', 'Every connection, in one place.'],
  ['monitoring', 'Monitoring', 'activity', 'Set a steady rhythm for your homelab.'],
  ['alerts', 'Alerts', 'shield', 'Keep the signals that matter.'],
  ['email', 'Email', 'ticket', 'A heads-up, wherever you are.'],
  ['security', 'Security', 'lock', 'Your Orbit sign-in, in your hands.'],
  ['data', 'Data & history', 'drive', 'Your readings, on your terms.'],
  ['system', 'System', 'server', 'What is happening behind the scenes.'],
  ['help', 'Help', 'globe', 'A little guidance when you need it.'],
];
function selectField(id, label, value, options, hint = '') {
  return `<div class="field"><label for="${id}">${label}</label><select id="${id}" name="${id}">${options.map(([key, text]) => `<option value="${esc(key)}" ${String(value) === String(key) ? 'selected' : ''}>${esc(text)}</option>`).join('')}</select>${hint ? `<small>${esc(hint)}</small>` : ''}</div>`;
}
function switchField(id, label, checked, description) {
  return `<label class="setting-switch" for="${id}"><span><strong>${esc(label)}</strong><small>${esc(description)}</small></span><input type="checkbox" id="${id}" name="${id}" ${checked ? 'checked' : ''}><span class="switch-track" aria-hidden="true"></span></label>`;
}
function settingsBlock(title, description, content) {
  return `<section class="settings-block"><div class="settings-block-heading"><h3>${title}</h3>${description ? `<p>${description}</p>` : ''}</div>${content}</section>`;
}
function saveBar(label = 'Save changes') {
  return `<div class="save-bar"><span id="dirty-status" role="status">All changes saved</span><div><button class="button" type="button" data-discard>Discard</button><button class="button primary" type="submit">${label}</button></div></div><p id="settings-error" class="field-error" role="alert" hidden></p>`;
}
function lockForm(form) {
  const controls = [...form.querySelectorAll('input,select,textarea,button')].map(element => [
    element,
    element.disabled,
  ]);
  for (const [element] of controls) element.disabled = true;
  busyForm = form;
  return () => {
    for (const [element, disabled] of controls) element.disabled = disabled;
    if (busyForm === form) busyForm = null;
  };
}
function formSnapshot(form) {
  if (!form) return '';
  return JSON.stringify(
    [...form.querySelectorAll('input,select,textarea')]
      .filter(el => !['export-source', 'export-range'].includes(el.id))
      .map(el => [el.id, el.value, ['checkbox', 'radio'].includes(el.type) ? el.checked : null])
  );
}
function pageForm() {
  return $('#settings-form') || $('#email-form') || $('#password-form');
}
function pageDirty() {
  return !!pageBaseline && formSnapshot(pageForm()) !== pageBaseline;
}
function drawerDirty() {
  return (
    !!drawerBaseline &&
    (formSnapshot($('#connection-form')) !== drawerBaseline ||
      JSON.stringify(draftRules) !== drawerRulesBaseline)
  );
}
function updateDirtyIndicator() {
  const dirty = pageDirty(),
    status = $('#dirty-status');
  if (status) {
    status.textContent = $('#password-form')
      ? dirty
        ? 'New password not saved'
        : 'Your sign-in is unchanged'
      : dirty
        ? 'You have unsaved changes'
        : 'All changes saved';
    status.classList.toggle('is-dirty', dirty);
  }
  $('#configuration-page').classList.toggle('has-unsaved', dirty);
}
function allowDrawerLeave() {
  if (busyForm?.id === 'connection-form') {
    toast('Finishing the connection save…');
    return false;
  }
  return !drawerDirty() || confirm('Discard your unsaved connection changes?');
}
function allowPageLeave() {
  if (reauthenticationRequired) {
    toast('Choose Sign in again to continue.');
    return false;
  }
  if (busyForm && busyForm.id !== 'connection-form') {
    toast('Finishing your request…');
    return false;
  }
  return !pageDirty() || confirm('Discard your unsaved configuration changes?');
}
function navigate(hash) {
  if (location.hash === hash || (hash === '#' && !location.hash)) return;
  if (!allowPageLeave()) return;
  if ($('#settings-dialog').open && !allowDrawerLeave()) return;
  pageBaseline = '';
  drawerBaseline = '';
  $('#settings-dialog').close();
  location.hash = hash;
}
function routeName() {
  const match = location.hash.match(/^#configure(?:\/([a-z]+))?$/);
  return match
    ? configurationSections.some(s => s[0] === match[1])
      ? match[1]
      : 'overview'
    : null;
}
function renderRoute(focus = true) {
  configurationSection = routeName();
  $('#dashboard-page').hidden = !!configurationSection;
  $('#configuration-page').hidden = !configurationSection;
  $('#settings').innerHTML = configurationSection
    ? 'Dashboard <span aria-hidden="true">↗</span>'
    : 'Configure <span aria-hidden="true">↗</span>';
  $('#settings').setAttribute(
    'aria-label',
    configurationSection ? 'Back to dashboard' : 'Open configuration'
  );
  if (!configurationSection) {
    pageBaseline = '';
    if (focus) $('#dashboard-title').closest('h1').setAttribute('tabindex', '-1');
    if (focus) $('#dashboard-title').closest('h1').focus({ preventScroll: true });
    // The chart could not be drawn or refreshed while the dashboard was hidden.
    if (expanded) {
      renderGraph(expanded);
      if (historyDue(expanded)) loadHistory(expanded);
    }
    return;
  }
  renderConfigurationNav();
  renderConfiguration();
  if (focus) {
    $('#configuration-section-title').focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
}
function renderConfigurationNav() {
  patchHtml(
    $('#configuration-nav'),
    configurationSections
      .map(
        ([key, label, symbol]) =>
          `<a href="#configure/${key}" ${key === configurationSection ? 'aria-current="page"' : ''}>${icon(symbol, 18)}<span>${label}</span>${key === 'sources' ? `<small>${data.config.services.length}</small>` : ''}</a>`
      )
      .join('')
  );
}
/** Brings the open configuration page up to date after `data` was reloaded. */
function refreshConfiguration() {
  if (!configurationSection) return;
  renderConfigurationNav();
  if (configurationSection === 'sources') renderSourceList();
  if (configurationSection === 'overview') renderConfiguration(true);
  // A form nobody has touched shows what is saved now, so a later save cannot revert a
  // change made elsewhere; a form with edits keeps them (the save then reports a conflict).
  const form = $('#settings-form') || $('#email-form');
  if (
    form &&
    Number.isInteger(data.config.revision) &&
    data.config.revision !== pageRevision &&
    !pageDirty() &&
    !busyForm
  ) {
    const focusedId = document.activeElement?.closest('#configuration-content')
      ? document.activeElement.id
      : '';
    renderConfiguration();
    if (focusedId) document.getElementById(focusedId)?.focus({ preventScroll: true });
  }
}
function renderConfiguration(refresh = false) {
  const c = data.config,
    a = c.appearance || {},
    m = c.monitoring || {},
    alerts = c.alerts || {},
    section = configurationSections.find(s => s[0] === configurationSection);
  if (!section) return;
  let content = '',
    form = false;
  if (configurationSection === 'overview') {
    const active = c.services.filter(s => s.enabled && stateFor(s.id).configured).length,
      hidden = c.services.filter(s => s.showOnDashboard === false).length;
    content = `<div class="configuration-welcome"><div class="welcome-orbit" aria-hidden="true">${icon('orbit', 40)}</div><div><p class="eyebrow">MADE FOR YOUR HOMELAB</p><h3>Everything in its place.</h3><p>Keep your dashboard quiet. Fine-tune the details here.</p></div></div><div class="configuration-stat-grid"><div><strong>${c.services.length}</strong><span>Sources in your workspace</span></div><div><strong>${active}</strong><span>Enabled connections</span></div><div><strong>${c.retentionDays}<small> days</small></strong><span>History retained</span></div></div>`;
    content += `<div class="settings-shortcuts">${[
      [
        'sources',
        'layers',
        'Your connections',
        `${hidden ? hidden + ' hidden · ' : ''}Add, organize, test and tune each source.`,
      ],
      [
        'appearance',
        'grid',
        'A view that feels like you',
        'Color, spacing and the details you see first.',
      ],
      [
        'monitoring',
        'activity',
        'Your collection rhythm',
        `Default interval: ${c.pollSeconds} seconds. Each source can have its own.`,
      ],
      [
        'alerts',
        'shield',
        'The right heads-up',
        `${alerts.enabled === false ? 'Alert evaluation is paused.' : data.alerts.length + ' active alerts.'} Choose how Orbit gets your attention.`,
      ],
    ]
      .map(
        ([key, symbol, title, copy]) =>
          `<a class="settings-shortcut" href="#configure/${key}"><span class="shortcut-icon">${icon(symbol, 22)}</span><div><h3>${title}</h3><p>${esc(copy)}</p></div><span aria-hidden="true">↗</span></a>`
      )
      .join(
        ''
      )}</div><p class="configuration-footnote">Changes stay on your Orbit server and apply to everyone who uses this dashboard.</p>`;
  }
  if (configurationSection === 'appearance') {
    form = true;
    content = settingsBlock(
      'Make it yours',
      'A familiar name, a little color, and room to breathe.',
      `${field('workspace-title', 'Dashboard name', c.title, { required: true, maxLength: 80 })}${field('workspace-subtitle', 'Subtitle', c.subtitle, { maxLength: 160, placeholder: 'Your homelab, at a glance' })}<fieldset class="accent-field"><legend>Accent color</legend><div class="accent-options">${['cyan', 'orange', 'blue', 'violet', 'amber', 'pink', 'green'].map(color => `<label style="--swatch:var(--${color})"><input type="radio" name="appearance-accent" value="${color}" ${(a.accent || 'cyan') === color ? 'checked' : ''}><span class="swatch" aria-hidden="true">✓</span><span>${color[0].toUpperCase() + color.slice(1)}</span></label>`).join('')}</div></fieldset>`
    );
    content += settingsBlock(
      'Layout & first impressions',
      'Choose how much of your workspace is on display.',
      `<div class="field-row">${selectField(
        'appearance-density',
        'Card spacing',
        a.density || 'comfortable',
        [
          ['comfortable', 'Comfortable'],
          ['compact', 'Compact'],
        ]
      )}${selectField(
        'appearance-columns',
        'Columns on larger screens',
        a.columns || 'auto',
        [
          ['auto', 'Automatic'],
          ['2', 'Two columns'],
          ['3', 'Three columns'],
          ['4', 'Four columns'],
        ],
        'Smaller screens adapt automatically.'
      )}</div><div class="field-row">${selectField(
        'appearance-range',
        'Default history view',
        a.defaultRange || '24h',
        [
          ['1h', 'Last hour'],
          ['6h', 'Last 6 hours'],
          ['24h', 'Last 24 hours'],
          ['7d', 'Last 7 days'],
          ['30d', 'Last 30 days'],
        ]
      )}${selectField('appearance-sort', 'Source order within groups', a.sortBy || 'manual', [
        ['manual', 'Saved order'],
        ['name', 'Alphabetical'],
        ['status', 'Needs attention first'],
      ])}</div>${switchField('appearance-summary', 'Summary strip', a.showSummary !== false, 'Connected sources, alerts, latest collection and history at a glance.')}${switchField('appearance-paused', 'Show paused sources', a.showPaused !== false, 'Keep deliberately paused services visible on the dashboard.')}${switchField('appearance-unconfigured', 'Show unconnected sources', a.showUnconfigured !== false, 'Keep sources that still need a connection visible.')}`
    );
    content += settingsBlock(
      'Everyday details',
      'Small preferences that make a difference.',
      `${switchField('appearance-newtab', 'Open services in a new tab', a.openInNewTab !== false, 'Your dashboard stays ready while you visit a service.')}${switchField('appearance-motion', 'Reduce motion', !!a.reduceMotion, 'Remove animations and smooth scrolling. System preferences are also respected.')}<div class="field-row">${field('appearance-timezone', 'Time zone', a.timezone || 'local', { required: true, placeholder: 'local or America/Chicago', hint: 'Use “local” for your browser’s time zone, or an IANA name such as America/Chicago.' })}${selectField(
        'appearance-timeformat',
        'Time format',
        a.timeFormat || 'auto',
        [
          ['auto', 'Browser default'],
          ['12h', '12-hour clock'],
          ['24h', '24-hour clock'],
        ]
      )}</div><div id="timezone-note">${timeZoneNote()}</div>`
    );
  }
  if (configurationSection === 'sources') {
    content = `<div class="source-toolbar"><div class="source-search"><label class="sr-only" for="source-search">Search sources</label><input id="source-search" type="search" placeholder="Find a source, group or type…" autocomplete="off"></div><div class="field filter-field"><label class="sr-only" for="source-filter">Filter sources</label><select id="source-filter"><option value="all">All sources</option><option value="connected">Connected</option><option value="attention">Needs attention</option><option value="unconfigured">Not connected</option><option value="paused">Paused</option><option value="hidden">Hidden from dashboard</option><option value="links">Bookmarks</option></select></div><button class="button primary" data-add-source>${icon('plus', 17)} Add source</button></div><p class="settings-info source-explainer">Hiding a source only changes the dashboard. Pausing it stops collection and alerts; saved history stays.</p><p id="source-results-count" class="source-results-count" role="status"></p><div id="configured-sources" class="configured-sources"></div>`;
  }
  if (configurationSection === 'monitoring') {
    form = true;
    content = settingsBlock(
      'Collection rhythm',
      'Collect often enough to stay informed, with room for your services to respond.',
      `<div class="field-row">${field('poll-seconds', 'Default interval (seconds)', c.pollSeconds, { type: 'number', min: 15, max: 3600, step: 1, required: true, hint: 'Applies to sources without their own interval.' })}${field('monitoring-timeout', 'Total collection deadline (seconds)', m.timeoutSeconds ?? 90, { type: 'number', min: 5, max: 120, step: 1, required: true, hint: 'Includes every attempt and retry delay within one scheduled check.' })}</div>${field('monitoring-concurrency', 'Simultaneous collections', m.concurrency ?? 4, { type: 'number', min: 1, max: 8, step: 1, required: true, hint: 'Lower this for busy networks or slower hosts. Range: 1–8.' })}<p class="settings-info">Manage individual intervals in <a class="text-link" href="#configure/sources">Sources</a>. Your browser refreshes readings automatically; collection continues when the dashboard is closed.</p>`
    );
    content += settingsBlock(
      'Retry failed checks',
      'Give a brief network interruption a second chance before recording a failed check.',
      `<div class="field-row">${field('monitoring-retries', 'Extra attempts', m.retryCount ?? 2, { type: 'number', min: 0, max: 3, step: 1, required: true, hint: '0 disables retries. 2 allows up to three attempts in total.' })}${field('monitoring-retry-delay', 'Delay between retries (seconds)', m.retryDelaySeconds ?? 2, { type: 'number', min: 1, max: 30, step: 1, required: true, hint: 'Wait between transient failures, within the total collection deadline.' })}</div><p class="settings-info">Only temporary network failures, timeouts and retryable HTTP responses are retried. Rejected credentials and invalid responses need attention instead. All attempts together produce one completed check.</p>`
    );
    content += settingsBlock(
      'Confirm problems & recovery',
      'Require a sustained pattern before starting or resolving an alert.',
      `<div class="field-row">${field('availability-failures', 'Failed checks before alerting', m.availabilityFailures ?? 2, { type: 'number', min: 1, max: 10, step: 1, required: true, hint: 'Consecutive completed checks that failed after retries.' })}${field('availability-seconds', 'Failure grace (seconds)', m.availabilitySeconds ?? 60, { type: 'number', min: 0, max: 3600, step: 1, required: true, hint: 'Both this duration and the failure count must be reached. 0 adds no extra delay.' })}</div><div class="field-row">${field('recovery-successes', 'Healthy checks before recovery', m.recoverySuccesses ?? 2, { type: 'number', min: 1, max: 10, step: 1, required: true, hint: 'Consecutive successful checks, including metric recovery when a threshold is active.' })}${field('recovery-seconds', 'Recovery grace (seconds)', m.recoverySeconds ?? 60, { type: 'number', min: 0, max: 3600, step: 1, required: true, hint: 'Recovery requires this duration and the healthy-check count. 0 adds no extra delay.' })}</div><p class="settings-info">Metric thresholds keep their own trigger duration. A recovery boundary can add breathing room, such as alerting above 90% memory and recovering at 88% or below. Retries do not suppress a real measurement warning. Override these defaults in each source when needed.</p>`
    );
  }
  if (configurationSection === 'alerts') {
    form = true;
    content = settingsBlock(
      'Alert behavior',
      'Connection failures and metric thresholds are different signals. A reachable service can still report high memory, disk pressure or application health warnings.',
      `${switchField('alerts-enabled', 'Evaluate alerts', alerts.enabled !== false, 'Checks connection failures and source thresholds. Turning this off clears active alerts while measurements continue.')}${switchField('alerts-availability', 'Connection notifications', alerts.notifyAvailability !== false, 'Send email or webhooks for failed checks and their recoveries. Active warnings remain visible when muted.')}${switchField('alerts-measurements', 'Metric notifications', alerts.notifyMeasurements !== false, 'Send email or webhooks for measured threshold breaches and their recoveries. Individual sources can override these category defaults.')}${switchField('alerts-start', 'Notify when an alert begins', alerts.notifyOnAlert !== false, 'Send through configured email and webhook delivery channels.')}${switchField('alerts-recovery', 'Notify when a source recovers', alerts.notifyOnRecovery !== false, 'Send a recovery message after an active alert resolves.')}`
    );
    content += settingsBlock(
      'Delivery & thresholds',
      'Use source-specific thresholds for the measurements that matter.',
      `<div class="delivery-row"><span class="shortcut-icon">${icon('ticket', 21)}</span><div><strong>Email</strong><p>${esc(emailStatusText())}</p></div><a class="button" href="#configure/email">Configure</a></div><div class="delivery-row"><span class="shortcut-icon">${icon('route', 21)}</span><div><strong>Webhook</strong><p>${data.notifications?.configured ? 'Configured on the Orbit server.' : 'Not configured. Set ORBIT_WEBHOOK_URL on the server to enable delivery.'}</p></div><a class="text-link" href="#configure/help">Setup guide ↗</a></div><div class="inline-actions"><a class="button" href="#configure/sources">Manage source thresholds</a><button class="button" type="button" data-view-alerts>View alerts & recent activity</button></div>`
    );
  }
  if (configurationSection === 'email')
    content = `${emailSettings()}<div class="email-dirty-note"><span id="dirty-status" role="status">All changes saved</span><button class="quiet-button" type="button" data-discard>Discard unsaved changes</button></div>`;
  if (configurationSection === 'data') {
    form = true;
    content = settingsBlock(
      'History that stays yours',
      'Measurements and alert events live on your Orbit server.',
      `${field('retention-days', 'Keep history for (days)', c.retentionDays, { type: 'number', min: 1, max: 365, step: 1, required: true, hint: 'Reducing retention removes older readings and events. This cannot be undone.' })}<div class="settings-hint">Historical graphs fill with real readings over time. Gaps remain visible when a source could not be reached; Orbit never invents missing measurements.</div>`
    );
    content += settingsBlock(
      'Take a copy',
      'Portable, readable exports for your own records.',
      `<div class="export-option"><div><h4>Configuration without credentials</h4><p>Download source definitions and preferences as JSON. Passwords and tokens are removed; private hostnames, addresses and account names remain. Keep this file private. It is a reference copy, not a full backup.</p></div><button class="button" type="button" id="export-config">${icon('download', 17)} Export configuration</button></div><div class="export-option"><div><h4>Readings as CSV</h4><p>Export a source’s sampled history for the selected range. Large ranges are grouped just like the graphs; failures and gaps are included.</p></div><div class="history-export-fields">${selectField(
        'export-source',
        'Source',
        c.services[0]?.id || '',
        c.services.map(s => [s.id, s.name])
      )}${selectField('export-range', 'History period', range, [
        ['1h', 'Last hour'],
        ['6h', 'Last 6 hours'],
        ['24h', 'Last 24 hours'],
        ['7d', 'Last 7 days'],
        ['30d', 'Last 30 days'],
      ])}<button class="button" type="button" id="export-history">${icon('download', 17)} Export CSV</button></div></div>`
    );
  }
  if (configurationSection === 'security')
    content =
      '<div id="security-details" class="settings-block"><p class="loading" role="status">Checking sign-in settings…</p></div>';
  if (configurationSection === 'system')
    content =
      '<div id="system-details" class="settings-block"><p class="loading" role="status">Reading system information…</p></div>';
  if (configurationSection === 'help')
    content = `<div class="help-layout"><div class="help-topics" role="group" aria-label="Documentation topics">${[
      ['installation', 'Installation'],
      ['configuration', 'Configuration'],
      ['integrations', 'Integrations'],
      ['architecture', 'How Orbit works'],
      ['security', 'Security'],
      ['troubleshooting', 'Troubleshooting'],
    ]
      .map(
        ([key, label]) =>
          `<button class="button" type="button" data-doc="${key}" aria-pressed="false">${label}</button>`
      )
      .join(
        ''
      )}</div><article id="documentation" class="documentation" aria-live="polite"><p class="loading">Opening the configuration guide…</p></article></div>`;
  const html = `<div class="configuration-section-heading"><p class="eyebrow">${esc(section[1])}</p><h2 id="configuration-section-title" tabindex="-1">${esc(section[3])}</h2></div>${form ? `<form id="settings-form" data-section="${configurationSection}">${content}${saveBar()}</form>` : content}`;
  // Refreshing updates the (form-free) overview in place, keeping focus on its links.
  if (refresh) {
    patchHtml($('#configuration-content'), html);
    return;
  }
  $('#configuration-content').innerHTML = html;
  pageRevision = data.config.revision;
  pageBaseline = formSnapshot(pageForm());
  updateDirtyIndicator();
  if (configurationSection === 'sources') renderSourceList();
  if (configurationSection === 'security') loadSecurity();
  if (configurationSection === 'system') loadSystem();
  if (configurationSection === 'help') loadDocumentation('configuration');
}
function renderSourceList() {
  const list = $('#configured-sources');
  if (!list) return;
  const query = ($('#source-search')?.value || '').trim().toLowerCase(),
    filter = $('#source-filter')?.value || 'all';
  const sources = data.config.services.filter(s => {
    const status = stateFor(s.id).status;
    return (
      (!query || [s.name, s.group, s.type].join(' ').toLowerCase().includes(query)) &&
      (filter === 'all' ||
        (filter === 'connected' && status === 'live') ||
        (filter === 'attention' &&
          (['error', 'stale'].includes(status) || data.alerts.some(a => a.service === s.id))) ||
        (filter === 'unconfigured' && status === 'unconfigured') ||
        (filter === 'paused' && !s.enabled) ||
        (filter === 'hidden' && s.showOnDashboard === false) ||
        (filter === 'links' && stateFor(s.id).collector === 'none'))
    );
  });
  $('#source-results-count').textContent =
    `${sources.length} of ${data.config.services.length} sources`;
  // Patched rather than replaced: the dashboard poll refreshes this list every 15 s.
  patchHtml(
    list,
    sources
      .map(s => {
        const state = stateFor(s.id),
          warnings = data.alerts.filter(a => a.service === s.id).length;
        return `<article class="configured-source" data-id="${esc(s.id)}" style="--accent:var(--${esc(s.color)})"><div class="service-icon">${icon(s.icon)}</div><div class="configured-source-info"><h3>${esc(s.name)}</h3><p><span class="state ${esc(state.status)}">${esc(states[state.status] || 'Unknown')}</span>${warnings ? `<span class="source-warning">${warnings} warning${warnings === 1 ? '' : 's'}</span>` : ''}<span>${esc(s.group)}</span><span>${s.pollSeconds ? `${s.pollSeconds}s` : `Default · ${data.config.pollSeconds}s`}</span>${s.showOnDashboard === false ? '<span class="hidden-source-tag">Hidden</span>' : ''}</p></div><div class="source-row-actions"><button class="quiet-button" data-visibility="${esc(s.id)}" aria-label="${s.showOnDashboard === false ? 'Show' : 'Hide'} ${esc(s.name)} on dashboard">${s.showOnDashboard === false ? 'Show' : 'Hide'}</button><button class="button" data-toggle="${esc(s.id)}" aria-label="${s.enabled ? 'Pause' : 'Resume'} ${esc(s.name)}">${s.enabled ? 'Pause' : 'Resume'}</button><button class="button" data-configure="${esc(s.id)}" aria-label="Edit ${esc(s.name)}">Edit</button></div></article>`;
      })
      .join('') ||
      '<div class="empty-history"><h4>No matching sources</h4><p>Try another search or filter, or add your first connection.</p></div>'
  );
}
function settingsInput(section) {
  const number = id => Number($('#' + id).value),
    check = id => $('#' + id).checked,
    value = id => $('#' + id).value;
  if (section === 'appearance')
    return {
      title: value('workspace-title'),
      subtitle: value('workspace-subtitle'),
      appearance: {
        accent: $('[name="appearance-accent"]:checked').value,
        density: value('appearance-density'),
        columns: value('appearance-columns'),
        defaultRange: value('appearance-range'),
        sortBy: value('appearance-sort'),
        showSummary: check('appearance-summary'),
        showPaused: check('appearance-paused'),
        showUnconfigured: check('appearance-unconfigured'),
        openInNewTab: check('appearance-newtab'),
        reduceMotion: check('appearance-motion'),
        timezone: value('appearance-timezone'),
        timeFormat: value('appearance-timeformat'),
      },
    };
  if (section === 'monitoring')
    return {
      pollSeconds: number('poll-seconds'),
      monitoring: {
        concurrency: number('monitoring-concurrency'),
        timeoutSeconds: number('monitoring-timeout'),
        availabilityFailures: number('availability-failures'),
        availabilitySeconds: number('availability-seconds'),
        retryCount: number('monitoring-retries'),
        retryDelaySeconds: number('monitoring-retry-delay'),
        recoverySuccesses: number('recovery-successes'),
        recoverySeconds: number('recovery-seconds'),
      },
    };
  if (section === 'alerts')
    return {
      alerts: {
        enabled: check('alerts-enabled'),
        notifyOnAlert: check('alerts-start'),
        notifyOnRecovery: check('alerts-recovery'),
        notifyAvailability: check('alerts-availability'),
        notifyMeasurements: check('alerts-measurements'),
      },
    };
  if (section === 'data') return { retentionDays: number('retention-days') };
  return {};
}
async function saveSettings(form) {
  if (!form.reportValidity()) return;
  const section = form.dataset.section,
    input = settingsInput(section),
    button = form.querySelector('[type=submit]'),
    error = $('#settings-error');
  if (
    section === 'data' &&
    input.retentionDays < data.config.retentionDays &&
    !confirm(
      `Keep only ${input.retentionDays} days of history? Older readings and events will be permanently removed.`
    )
  )
    return;
  const unlock = lockForm(form);
  error.hidden = true;
  try {
    const result = await writeConfig(
      '/api/settings',
      { method: 'PATCH', body: JSON.stringify(input) },
      { revision: () => pageRevision, apply: config => mergeSettings(config, input) }
    );
    pageBaseline = formSnapshot(form);
    pageRevision = result.revision ?? pageRevision;
    if (input.appearance) range = input.appearance.defaultRange;
    await load();
    if ($('#timezone-note')) $('#timezone-note').innerHTML = timeZoneNote();
    updateDirtyIndicator();
    toast('Your changes are saved.');
  } catch (e) {
    // Other devices' changes are not overwritten; Discard loads them into this form.
    error.textContent =
      e.status === 409
        ? `${conflictMessage} Choose Discard to load the latest settings, then make your change again.`
        : e.message;
    error.hidden = false;
    error.scrollIntoView({ block: 'nearest' });
    if (e.status === 409) await load();
  } finally {
    unlock();
  }
}
async function loadSecurity() {
  const target = $('#security-details');
  if (!target) return;
  try {
    const system = await api('/api/system');
    if (target !== $('#security-details')) return;
    const auth = system.authentication;
    if (!auth?.passwordChangeAvailable) {
      target.innerHTML = `<div class="settings-block-heading"><h3>Sign in to change your password</h3><p>This installation does not have Orbit sign-in enabled. A local preview first needs its server password configured. On your protected Orbit instance, return here while signed in.</p></div><div class="account-identity">${icon('lock', 20)}<div><span>Orbit username</span><strong>admin</strong></div></div>`;
      pageBaseline = '';
      return;
    }
    target.innerHTML = `<div class="settings-block-heading"><h3>Change your Orbit password</h3><p>Confirm your current password, then choose a new one.</p></div><div class="account-identity">${icon('lock', 20)}<div><span>Orbit username</span><strong>admin</strong></div><small>${auth.passwordChangedAt ? 'Last changed ' + esc(dateTime(auth.passwordChangedAt)) : 'Not changed in Orbit yet'}</small></div><form id="password-form"><div class="field"><label for="current-password">Current password</label><input id="current-password" name="current-password" type="password" autocomplete="current-password" required></div><div class="field"><label for="new-password">New password</label><input id="new-password" name="new-password" type="password" autocomplete="new-password" required aria-describedby="password-guidance"><small id="password-guidance">Use at least 12 characters. A long, unique passphrase is a good choice. Spaces are kept exactly as entered.</small></div><div class="field"><label for="confirm-new-password">Confirm new password</label><input id="confirm-new-password" name="confirm-new-password" type="password" autocomplete="new-password" required></div><p class="settings-info">This changes the shared admin sign-in for Orbit. Other browsers will need the new password too. After saving, choose <strong>Sign in again</strong> and use <strong>admin</strong> with your new password.</p><p id="password-error" class="field-error" role="alert" hidden></p><div class="save-bar password-save-bar"><span id="dirty-status" role="status">Your sign-in is unchanged</span><div><button class="button" type="button" data-discard>Discard</button><button class="button primary" type="submit">Change password</button></div></div></form>`;
    pageBaseline = formSnapshot($('#password-form'));
    updateDirtyIndicator();
  } catch (error) {
    if (target === $('#security-details'))
      target.innerHTML = `<p class="field-error" role="alert">${esc(error.message)}</p><button class="button" type="button" id="retry-security">Try again</button>`;
  }
}
function passwordInputError(password, confirmation) {
  if ([...password].length < 12) return 'Use at least 12 characters for your new password.';
  if (new TextEncoder().encode(password).length > 1024)
    return 'This password is too long. Use no more than 1,024 UTF-8 bytes.';
  if (password !== confirmation)
    return 'The two passwords do not match. Enter the same new password in both fields.';
  return '';
}
function finishPasswordChange(confirmed) {
  const form = $('#password-form');
  if (form) for (const input of form.querySelectorAll('input')) input.value = '';
  pageBaseline = '';
  drawerBaseline = '';
  reauthenticationRequired = true;
  clearInterval(dashboardPollTimer);
  for (const controller of activeApiRequests) controller.abort();
  testController?.abort();
  $('#refresh').disabled = true;
  $('#settings').disabled = true;
  $('#connection').textContent = 'Sign in again';
  $('#connection').classList.remove('live');
  const target = $('#security-details');
  target.innerHTML = `<div class="password-result" role="status"><span class="password-result-icon">${icon(confirmed ? 'check' : 'lock', 26)}</span><h3>${confirmed ? 'Password changed' : 'Check your sign-in'}</h3><p>${confirmed ? 'Your new password is saved. Background requests are paused until you sign in again.' : 'The connection ended before Orbit could confirm the change. It may have been saved. Background requests are paused so you can check your sign-in.'}</p><p>Use username <strong>admin</strong> and ${confirmed ? 'your new password' : 'try the new password you entered'} when your browser asks.</p><button class="button primary" type="button" id="sign-in-again">Sign in again</button></div>`;
  updateDirtyIndicator();
  $('#sign-in-again').focus({ preventScroll: true });
}
async function changePassword(form) {
  if (!form.reportValidity() || passwordChangePending || reauthenticationRequired) return;
  const currentPassword = $('#current-password').value,
    password = $('#new-password').value,
    confirmation = $('#confirm-new-password').value,
    error = $('#password-error'),
    invalid = passwordInputError(password, confirmation);
  error.hidden = true;
  if (invalid) {
    error.textContent = invalid;
    error.hidden = false;
    return;
  }
  const unlock = lockForm(form);
  passwordChangePending = true;
  $('#refresh').disabled = true;
  for (const controller of activeApiRequests) controller.abort();
  try {
    const result = await api('/api/auth/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, password, confirmPassword: confirmation }),
    });
    if (!result.ok || !result.reauthenticate)
      throw new Error('Password update could not be confirmed.');
    finishPasswordChange(true);
  } catch (failure) {
    if (!failure.status) {
      finishPasswordChange(false);
    } else {
      error.textContent = failure.message;
      error.hidden = false;
    }
  } finally {
    passwordChangePending = false;
    unlock();
    if (!reauthenticationRequired) $('#refresh').disabled = false;
  }
}
async function loadSystem() {
  const target = $('#system-details');
  if (!target) return;
  try {
    const s = await api('/api/system');
    if (target !== $('#system-details')) return;
    const rows = entries =>
      `<dl class="system-facts">${entries.map(([label, value]) => `<div><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`).join('')}</dl>`;
    target.innerHTML = `<div class="system-status"><span class="system-status-dot" aria-hidden="true"></span><div><h3>Orbit is online</h3><p>System information as of ${esc(when(Date.now()))}</p></div><button class="button" type="button" id="refresh-system">Refresh</button></div>${settingsBlock(
      'Your installation',
      '',
      rows([
        ['Orbit version', s.version],
        ['Running for', format(s.uptimeSeconds, 'seconds')],
        ['Started', dateTime(s.startedAt)],
        ['Sign-in protection', s.authenticationRequired ? 'Required' : 'No Orbit password set'],
      ])
    )}${settingsBlock(
      'Collection right now',
      '',
      rows([
        ['In progress', s.collection.inflight],
        ['Waiting', s.collection.pending],
        ['Concurrency', s.collection.concurrency],
        ['Timeout', s.collection.timeoutSeconds + ' seconds'],
        ['Last successful collection', dateTime(s.collection.lastCollected)],
      ])
    )}${settingsBlock(
      'Local storage',
      '',
      rows([
        ['Database', format(s.data.databaseBytes, 'bytes')],
        [
          'History writes',
          s.data.writeFailure
            ? `Failing since ${dateTime(s.data.writeFailure.since)} (${s.data.writeFailure.code})`
            : 'Working',
        ],
        ['Configuration', format(s.data.configBytes, 'bytes')],
        ['Saved readings', s.data.samples.toLocaleString()],
        ['Alert events', s.data.events.toLocaleString()],
        ['Active alerts', s.data.activeAlerts],
      ])
    )}${settingsBlock(
      'Workspace limits',
      '',
      rows([
        ['Sources', s.limits.sources],
        ['Mappings per source', s.limits.mappingsPerSource],
        ['Rules per source', s.limits.rulesPerSource],
      ])
    )}<p class="configuration-footnote">This page is a snapshot. Refresh to read the latest state.</p>`;
  } catch (e) {
    if (target === $('#system-details'))
      target.innerHTML = `<p class="field-error" role="alert">${esc(e.message)}</p><button class="button" type="button" id="refresh-system">Try again</button>`;
  }
}
function markdownInline(text) {
  const tokens = [];
  const token = html => {
    tokens.push(html);
    return `\u0000${tokens.length - 1}\u0000`;
  };
  text = String(text)
    .replace(/\u0000/g, '')
    .replace(/`([^`]+)`/g, (_, code) => token(`<code>${esc(code)}</code>`));
  text = text.replace(/\[([^\]\n]+)\]\(([^\s)]+)\)/g, (_, label, url) => {
    const local = url.match(
      /^(?:\.\/)?(?:docs\/)?(installation|configuration|integrations|architecture|security|troubleshooting)\.md(?:#[\w-]+)?$/i
    );
    if (local)
      return token(
        `<button class="doc-inline-link" type="button" data-doc="${local[1].toLowerCase()}">${esc(label)}</button>`
      );
    try {
      const target = new URL(url);
      if (['https:', 'http:'].includes(target.protocol) && !target.username && !target.password)
        return token(
          `<a href="${esc(target.href)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>`
        );
    } catch {}
    return token(esc(label));
  });
  return esc(text)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\u0000(\d+)\u0000/g, (_, index) => tokens[Number(index)]);
}
function renderMarkdown(markdown) {
  const lines = String(markdown).replace(/\r\n/g, '\n').split('\n'),
    output = [];
  let index = 0;
  const tableCells = line =>
    line
      .trim()
      .replace(/^\||\|$/g, '')
      .split('|')
      .map(cell => cell.trim());
  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) {
      index++;
      continue;
    }
    if (/^\s*```/.test(line)) {
      const code = [];
      index++;
      while (index < lines.length && !/^\s*```/.test(lines[index])) code.push(lines[index++]);
      if (index < lines.length) index++;
      output.push(`<pre><code>${esc(code.join('\n'))}</code></pre>`);
      continue;
    }
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) {
      if (heading[1].length === 1 && !output.length) {
        index++;
        continue;
      }
      const level = Math.min(4, heading[1].length + 1);
      output.push(`<h${level}>${markdownInline(heading[2])}</h${level}>`);
      index++;
      continue;
    }
    if (
      index + 1 < lines.length &&
      line.includes('|') &&
      /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[index + 1])
    ) {
      const headers = tableCells(line);
      index += 2;
      const rows = [];
      while (index < lines.length && lines[index].includes('|') && lines[index].trim())
        rows.push(tableCells(lines[index++]));
      output.push(
        `<div class="table-scroll"><table><thead><tr>${headers.map(cell => `<th scope="col">${markdownInline(cell)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${headers.map((_, i) => `<td>${markdownInline(row[i] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
      );
      continue;
    }
    const list = line.match(/^\s*(?:([-*+])|(\d+)[.)])\s+(.+)$/);
    if (list) {
      const ordered = !!list[2],
        items = [];
      while (index < lines.length) {
        const item = lines[index].match(/^\s*(?:([-*+])|(\d+)[.)])\s+(.+)$/);
        if (!item || !!item[2] !== ordered) break;
        items.push(markdownInline(item[3]));
        index++;
      }
      output.push(
        `<${ordered ? 'ol' : 'ul'}>${items.map(item => `<li>${item}</li>`).join('')}</${ordered ? 'ol' : 'ul'}>`
      );
      continue;
    }
    if (/^\s*(?:---+|\*\*\*+)\s*$/.test(line)) {
      output.push('<hr>');
      index++;
      continue;
    }
    const paragraph = [line];
    index++;
    while (
      index < lines.length &&
      lines[index].trim() &&
      !/^(?:#{1,6}\s|\s*```|\s*[-*+]\s|\s*\d+[.)]\s)/.test(lines[index]) &&
      !(lines[index].includes('|') && /^\s*\|?\s*:?-{3,}/.test(lines[index + 1] || ''))
    )
      paragraph.push(lines[index++]);
    output.push(`<p>${markdownInline(paragraph.join(' '))}</p>`);
  }
  return output.join('');
}
let documentationRequest = 0;
async function loadDocumentation(doc) {
  const request = ++documentationRequest,
    target = $('#documentation');
  if (!target) return;
  document
    .querySelectorAll('[data-doc]')
    .forEach(b => b.setAttribute('aria-pressed', String(b.dataset.doc === doc)));
  target.innerHTML = '<p class="loading">Opening guide…</p>';
  try {
    const result = await api('/api/docs?doc=' + encodeURIComponent(doc));
    if (request !== documentationRequest || target !== $('#documentation')) return;
    target.innerHTML = `<h3>${esc(result.title)}</h3><div class="documentation-body">${renderMarkdown(result.markdown)}</div>`;
  } catch (e) {
    if (request === documentationRequest && target === $('#documentation'))
      target.innerHTML = `<p class="field-error" role="alert">${esc(e.message)}</p><button class="button" type="button" data-doc="${esc(doc)}">Try again</button>`;
  }
}
function downloadFile(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type })),
    a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function exportConfiguration(button) {
  button.disabled = true;
  try {
    const result = await api('/api/config/export');
    downloadFile(
      'orbit-config-redacted.json',
      JSON.stringify(result, null, 2) + '\n',
      'application/json'
    );
    toast('Configuration exported. Private hostnames are included.');
  } catch (e) {
    toast(e.message);
  } finally {
    button.disabled = false;
  }
}
async function exportHistory(id, selectedRange, button) {
  if (!id) {
    toast('Add a source before exporting readings.');
    return;
  }
  button.disabled = true;
  try {
    const history = await api(
        `/api/history/${encodeURIComponent(id)}?range=${encodeURIComponent(selectedRange)}`
      ),
      source = data.config.services.find(s => s.id === id);
    if (!history.points.length) {
      toast('There are no saved readings in this period.');
      return;
    }
    const cell = value =>
      '"' +
      String(value ?? '')
        .replace(/^[=+@\-\t\r]/, "'$&")
        .replaceAll('"', '""') +
      '"';
    const rows = [
      ['timestamp_utc', 'status', 'gap_before', 'metric', 'label', 'value', 'unit', 'error'],
    ];
    for (const p of history.points) {
      if (!p.ok)
        rows.push([
          new Date(p.time).toISOString(),
          p.gap ? 'gap' : 'failed',
          !!p.gapBefore,
          '',
          '',
          '',
          '',
          p.error ?? '',
        ]);
      else
        for (const metric of p.metrics)
          rows.push([
            new Date(p.time).toISOString(),
            'ok',
            !!p.gapBefore,
            metric.key,
            metric.label,
            metric.value,
            metric.unit,
            '',
          ]);
    }
    // The byte order mark makes Excel read the file as UTF-8 rather than a legacy code
    // page, which would garble the '·', '’' and '…' in labels and error text.
    downloadFile(
      `orbit-${source?.id || id}-${selectedRange}.csv`,
      '\ufeff' +
        rows
          .map(row =>
            row
              .map((value, i) =>
                i === 5 && typeof value === 'number' ? String(value) : cell(value)
              )
              .join(',')
          )
          .join('\r\n') +
        '\r\n',
      'text/csv;charset=utf-8'
    );
    toast('Sampled history exported.');
  } catch (e) {
    toast(e.message);
  } finally {
    button.disabled = false;
  }
}
document.addEventListener('input', e => {
  if (e.target.closest('#configuration-content')) updateDirtyIndicator();
  if (e.target.id === 'source-search') renderSourceList();
});
document.addEventListener('change', e => {
  if (e.target.closest('#configuration-content')) updateDirtyIndicator();
  if (e.target.id === 'source-filter') renderSourceList();
});
document.addEventListener('click', async e => {
  if (e.target.closest('#sign-in-again')) {
    pageBaseline = '';
    drawerBaseline = '';
    location.reload();
    return;
  }
  if (e.target.closest('#retry-security')) {
    await loadSecurity();
    return;
  }
  const routeLink = e.target.closest('a[href^="#"]');
  if (routeLink && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && e.button === 0) {
    e.preventDefault();
    navigate(routeLink.getAttribute('href'));
    return;
  }
  if (e.target.closest('[data-discard]')) {
    if (allowPageLeave()) renderConfiguration();
    return;
  }
  const hidden = e.target.closest('[data-visibility]');
  if (hidden) {
    const source = data.config.services.find(s => s.id === hidden.dataset.visibility);
    hidden.disabled = true;
    try {
      await writeConfig(
        '/api/services/' + encodeURIComponent(source.id),
        {
          method: 'PATCH',
          body: JSON.stringify({ showOnDashboard: source.showOnDashboard === false }),
        },
        { revision: () => data.config.revision, apply: replaceService, source: source.id }
      );
      await load();
      toast(
        source.showOnDashboard === false
          ? 'Source shown on the dashboard.'
          : 'Source hidden. Monitoring continues.'
      );
    } catch (error) {
      toast(
        error.status === 409
          ? `${conflictMessage} The latest settings are shown now.`
          : error.message
      );
      hidden.disabled = false;
      if (error.status === 409) await load();
    }
    return;
  }
  if (e.target.closest('[data-view-alerts]')) {
    renderAlerts();
    $('#alerts-dialog').showModal();
    return;
  }
  const doc = e.target.closest('[data-doc]');
  if (doc) {
    await loadDocumentation(doc.dataset.doc);
    return;
  }
  if (e.target.closest('#refresh-system')) {
    await loadSystem();
    return;
  }
  const configExport = e.target.closest('#export-config');
  if (configExport) {
    await exportConfiguration(configExport);
    return;
  }
  const historyExport = e.target.closest('[data-export-history]');
  if (historyExport) {
    await exportHistory(historyExport.dataset.exportHistory, range, historyExport);
    return;
  }
  const exportButton = e.target.closest('#export-history');
  if (exportButton)
    await exportHistory($('#export-source').value, $('#export-range').value, exportButton);
});
document.addEventListener('submit', async e => {
  if (e.target.id === 'password-form') {
    e.preventDefault();
    await changePassword(e.target);
  }
  if (e.target.id === 'settings-form') {
    e.preventDefault();
    await saveSettings(e.target);
  }
  if (e.target.matches('#settings-dialog .dialog-heading') && !allowDrawerLeave())
    e.preventDefault();
});
// Escape is handled here: Chromium ignores preventDefault() on the 'cancel' event of a
// second Escape without user activation in between, which would close a drawer the user
// chose to keep. Cancelling the keydown stops that close request altogether. (On the
// document, because focus can sit on <body> while the modal drawer is open.)
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape' || e.isComposing || e.defaultPrevented) return;
  if (!$('#settings-dialog').open || $('#alerts-dialog').open) return;
  e.preventDefault();
  if (allowDrawerLeave()) $('#settings-dialog').close();
});
$('#settings-dialog').addEventListener('cancel', e => {
  if (!allowDrawerLeave()) e.preventDefault();
});
$('#settings-dialog').addEventListener('close', () => {
  drawerBaseline = '';
  document.body.append($('#toast'));
});
// Each accepted route records its position in history.state, so a refused Back or Forward
// can return to the entry the user was on instead of overwriting the one they left for.
if (Number.isInteger(history.state?.orbitIndex)) acceptedIndex = history.state.orbitIndex;
else history.replaceState({ orbitIndex: acceptedIndex }, '');
window.addEventListener('hashchange', () => {
  const index = history.state?.orbitIndex;
  if (restoringRoute && location.hash === acceptedHash) {
    restoringRoute = false;
    return;
  }
  restoringRoute = false;
  if (!allowPageLeave() || ($('#settings-dialog').open && !allowDrawerLeave())) {
    // A new entry (link or typed URL) sits just after the accepted one.
    const delta = acceptedIndex - (Number.isInteger(index) ? index : acceptedIndex + 1);
    if (delta) {
      restoringRoute = true;
      history.go(delta);
    } else
      history.replaceState(
        { orbitIndex: acceptedIndex },
        '',
        location.pathname + location.search + acceptedHash
      );
    return;
  }
  if (Number.isInteger(index)) acceptedIndex = index;
  else history.replaceState({ orbitIndex: ++acceptedIndex }, '');
  acceptedHash = location.hash;
  pageBaseline = '';
  drawerBaseline = '';
  $('#settings-dialog').close();
  if (data) renderRoute();
});
window.addEventListener('beforeunload', e => {
  if (pageDirty() || drawerDirty() || busyForm) {
    e.preventDefault();
    e.returnValue = '';
  }
});
$('#configuration-nav').addEventListener('keydown', e => {
  const links = [...$('#configuration-nav').querySelectorAll('a')],
    index = links.indexOf(e.target);
  if (index < 0) return;
  let next;
  if (e.key === 'ArrowDown' || e.key === 'ArrowRight') next = (index + 1) % links.length;
  else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft')
    next = (index - 1 + links.length) % links.length;
  else if (e.key === 'Home') next = 0;
  else if (e.key === 'End') next = links.length - 1;
  else return;
  e.preventDefault();
  links[next].focus();
});
clock();
setInterval(clock, 30000);
load();
const pollDashboard = () => {
  if (
    !document.hidden &&
    !$('#settings-dialog').open &&
    !passwordChangePending &&
    !reauthenticationRequired
  )
    load();
};
dashboardPollTimer = setInterval(pollDashboard, 15000);
// Polling stops in a background tab; catch up at once, so a drawer or form opened after
// returning starts from the current configuration.
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && data) pollDashboard();
});
