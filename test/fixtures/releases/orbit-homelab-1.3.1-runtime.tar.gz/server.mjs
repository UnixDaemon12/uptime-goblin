import http from 'node:http';
import {setTimeout as delay} from 'node:timers/promises';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {PasswordAuth,AuthError} from './lib/auth.mjs';
import {publicConfig,definitions,collectorType} from './lib/catalog.mjs';
import {ConfigStore,InputError,validateService} from './lib/config.mjs';
import {Store,periods} from './lib/store.mjs';
import {collect,resetCollector} from './lib/collectors.mjs';
import {EmailNotifier,emailConfigured} from './lib/mail.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const noCollector=s=>collectorType(s)==='none';
const configured=s=>!noCollector(s)&&Boolean(s.apiUrl||(collectorType(s)==='http'&&s.url));
async function body(req){let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>150000)throw new InputError('Request is too large');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString());}catch{throw new InputError('Expected valid JSON');}}
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
function collectionError(e,service){let error=e instanceof TypeError?'Collection failed. Check the address and credential format.':String(e.message||'Collection failed');for(const secret of [service.apiKey,service.password])if(secret)error=error.split(secret).join('[redacted]');error=error.slice(0,300);if(/https?:\/\/|token|password|authorization|sessionID/i.test(error)&&!/Check|check|permissions|Authentication|authentication/.test(error))error='Collection failed. Check the endpoint, credentials, and source compatibility.';return error;}
export function createApp({directory=process.env.ORBIT_DATA_DIR||path.join(root,'data'),host=process.env.HOST||'127.0.0.1',port=Number(process.env.PORT||4317),password=process.env.ORBIT_PASSWORD||'',allowedHosts=process.env.ORBIT_ALLOWED_HOSTS||'',collector=collect,startScheduler=true,collectionTimeoutMs,webhook=process.env.ORBIT_WEBHOOK_URL||'',mailTransportFactory,emailTimeoutMs=20000}={}){
 const auth=new PasswordAuth(directory,password);password='';
 if(!['127.0.0.1','::1','localhost'].includes(host)&&!auth.required)throw new Error('Set ORBIT_PASSWORD before listening on a network interface.');
 const config=new ConfigStore(directory),store=new Store(directory);const inflight=new Map(),due=new Map(),connectionTests=new Map(),notificationsPending=new Set();let closed=false,lastPruned=0,lastNotificationError=null,nextEmailTest=0;
 const startedAt=Date.now(),version=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version;
 const interval=s=>s.pollSeconds||config.value.pollSeconds;
 const monitoring=s=>({...config.value.monitoring,...s?.monitoring});
 const timeoutMs=s=>collectionTimeoutMs??monitoring(s).timeoutSeconds*1000;
 const email=new EmailNotifier({getSettings:()=>config.value.email,transportFactory:mailTransportFactory,timeoutMs:emailTimeoutMs});
 const configuredHosts=new Set(allowedHosts.split(',').map(h=>h.trim().toLowerCase()).filter(Boolean));
 const allowedHost=value=>{if(!value)return false;if(configuredHosts.has(value.toLowerCase()))return true;const currentPort=server.address()?.port||port;return [`127.0.0.1:${currentPort}`,`localhost:${currentPort}`,`[::1]:${currentPort}`].includes(value.toLowerCase());};
 async function notifyWebhook(event){if(!webhook)return;try{const res=await fetch(webhook,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:'orbit',...event}),signal:AbortSignal.timeout(8000),redirect:'error'});if(!res.ok)throw new Error();lastNotificationError=null;}catch{lastNotificationError=Date.now();console.error('Alert webhook delivery failed; see the in-app alerts.');}}
 function notify(event){const settings=config.value.alerts,category=event.category==='availability'?'notifyAvailability':'notifyMeasurements';if(!settings.enabled||(event.kind==='firing'&&!settings.notifyOnAlert)||(event.kind==='resolved'&&!settings.notifyOnRecovery)||(config.get(event.service)?.alerts?.[category]??settings[category])===false)return;const pending=Promise.allSettled([notifyWebhook(event),email.send(event)]);notificationsPending.add(pending);void pending.finally(()=>notificationsPending.delete(pending));}
 // Race the whole attempt against cancellation, including collectors that stop responding.
 function attempt(run,signal){return new Promise((resolve,reject)=>{
  const cancel=()=>{signal.removeEventListener('abort',cancel);reject(signal.reason);};
  if(signal.aborted){cancel();return;}signal.addEventListener('abort',cancel,{once:true});
  Promise.resolve().then(()=>{signal.throwIfAborted();return run();}).then(value=>{signal.removeEventListener('abort',cancel);resolve(value);},error=>{signal.removeEventListener('abort',cancel);reject(error);});
 });}
 async function collectLogical(service,signal){
  const options=monitoring(service),sessionRefreshBudget={remaining:1},deadline=new AbortController(),timeout=setTimeout(()=>deadline.abort(),timeoutMs(service)),combined=AbortSignal.any([signal,deadline.signal]);
  try{for(let index=0;;index++){
   combined.throwIfAborted();const controller=new AbortController(),attemptSignal=AbortSignal.any([combined,controller.signal]);let failure;
   try{return await attempt(()=>collector({...service,apiUrl:service.apiUrl||service.url,type:collectorType(service),signal:attemptSignal,sessionRefreshBudget}),attemptSignal);}
   catch(error){combined.throwIfAborted();if(error.retryable!==true||index>=options.retryCount)throw error;failure=error;}
   finally{controller.abort();}
   // Only transient failures reach this wait. The same total deadline covers every attempt.
   if(failure)await delay(options.retryDelaySeconds*1000,undefined,{signal:combined});
  }}catch(error){if(signal.aborted)throw signal.reason;if(deadline.signal.aborted)throw new Error('Collection exceeded its time limit. Try fewer devices or a more focused source.');throw error;}
  finally{clearTimeout(timeout);deadline.abort();}
 }
 async function poll(service){
  const version=JSON.stringify(service);if(closed||inflight.has(service.id)||!service.enabled||!configured(service)||JSON.stringify(config.get(service.id))!==version)return;
  const controller=new AbortController();inflight.set(service.id,controller);let metrics=[],error=null;
  try{try{metrics=await collectLogical(service,controller.signal);}catch(e){error=collectionError(e,service);}
   const current=config.get(service.id);if(closed||controller.signal.aborted||!current?.enabled||JSON.stringify(current)!==version)return;
   const time=Date.now(),options=monitoring(service);store.record(service.id,metrics,error,time);
   if(config.value.alerts.enabled)for(const event of store.evaluate({...service,...options,pollSeconds:interval(service),collectionTimeoutSeconds:timeoutMs(service)/1000},metrics,error,time))void notify(event);
  }finally{inflight.delete(service.id);due.set(service.id,!controller.signal.aborted&&JSON.stringify(config.get(service.id))===version?Date.now()+interval(service)*1000:0);}
 }
 async function tick(force=false){
  if(closed)return;const now=Date.now(),capacity=Math.max(0,config.value.monitoring.concurrency-inflight.size);
  const queue=config.value.services.filter(s=>s.enabled&&configured(s)&&!inflight.has(s.id)&&(force||!due.has(s.id)||due.get(s.id)<=now)).sort((a,b)=>(due.get(a.id)||0)-(due.get(b.id)||0));
  // Separate ticks may fill free slots while another source is still waiting.
  const workers=Array.from({length:Math.min(capacity,queue.length)},async()=>{while(queue.length&&!closed){if(inflight.size>=config.value.monitoring.concurrency)return;const next=queue.shift();if(inflight.has(next.id)||(!force&&due.get(next.id)>Date.now()))continue;await poll(next);}});
  await Promise.all(workers);if(!closed&&now-lastPruned>3600000){lastPruned=now;store.prune(config.value.retentionDays,now);}
 }
 function dashboard(){const states=config.value.services.map(s=>{const latest=store.latest(s.id);const status=!s.enabled?'disabled':noCollector(s)?'link':!configured(s)?'unconfigured':latest.error?latest.lastSuccess?'stale':'error':!latest.lastSuccess?'collecting':Date.now()-latest.lastSuccess>interval(s)*2500?'stale':'live';return {...latest,status,collecting:inflight.has(s.id),configured:configured(s),collector:collectorType(s)};});const active=new Set(config.value.services.filter(s=>s.enabled&&configured(s)).map(s=>s.id));const alerts=store.alerts().filter(a=>active.has(a.service)).map(a=>({...a,name:config.get(a.service)?.name}));return {config:publicConfig(config.value),catalog:definitions.map(([type,name,group,color,icon,labels])=>({type,name,group,color,icon,labels})),services:states,alerts,events:store.events().filter(e=>config.get(e.service)).map(e=>({...e,name:config.get(e.service)?.name})),lastCollected:Math.max(0,...states.map(s=>s.lastSuccess||0))||null,notifications:{configured:Boolean(webhook),lastError:lastNotificationError,webhook:{configured:Boolean(webhook),lastError:lastNotificationError},email:email.status()}};}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  try{
   if(!allowedHost(req.headers.host)){json(res,403,{error:'Host is not allowed. Add this hostname and port to ORBIT_ALLOWED_HOSTS.'});return;}
   const access=await auth.authenticate(req.headers.authorization);if(!access){res.setHeader('WWW-Authenticate','Basic realm="Orbit", charset="UTF-8"');json(res,401,{error:'Sign in to Orbit'});return;}
   const readBody=async()=>{const value=await body(req);auth.assertCurrent(access);return value;};
   const url=new URL(req.url,'http://localhost');
   if(req.method!=='GET'&&req.method!=='HEAD'){
    const origin=req.headers.origin;let sameOrigin=false;if(origin){try{sameOrigin=new URL(origin).host===req.headers.host;}catch{}}
    if(req.headers['x-orbit-request']!=='1'||(origin&&!sameOrigin)||req.headers['sec-fetch-site']==='cross-site'){json(res,403,{error:'Cross-origin changes are not allowed'});return;}
    if(req.headers['content-type']?.split(';')[0]!=='application/json'){json(res,415,{error:'JSON requests are required'});return;}
   }
   if(url.pathname==='/api/auth/password'&&req.method==='POST'){if(!auth.required)throw new AuthError('Password changes require an authenticated Orbit session.',403);json(res,200,await auth.change(await readBody(),access));return;}
   if(url.pathname==='/api/dashboard'&&req.method==='GET'){json(res,200,dashboard());return;}
   if(url.pathname==='/api/system'&&req.method==='GET'){
    const size=name=>{try{return fs.statSync(path.join(directory,name)).size;}catch{return 0;}};
    json(res,200,{version,nodeVersion:process.versions.node,uptimeSeconds:Math.floor((Date.now()-startedAt)/1000),startedAt,platform:process.platform,architecture:process.arch,authenticationRequired:auth.required,authentication:auth.metadata(),data:{databaseBytes:size('history.sqlite')+size('history.sqlite-wal'),configBytes:size('config.json'),...store.stats()},collection:{concurrency:config.value.monitoring.concurrency,timeoutSeconds:timeoutMs()/1000,pending:config.value.services.filter(s=>s.enabled&&configured(s)&&!inflight.has(s.id)&&(!due.has(s.id)||due.get(s.id)<=Date.now())).length,inflight:inflight.size,lastCollected:dashboard().lastCollected},limits:{sources:200,mappingsPerSource:100,rulesPerSource:30},notifications:{email:email.status(),webhookConfigured:Boolean(webhook)}});return;
   }
   if(url.pathname==='/api/config/export'&&req.method==='GET'){
    res.setHeader('Content-Disposition','attachment; filename="orbit-config-redacted.json"');json(res,200,{format:'orbit-config',version:1,exportedAt:new Date().toISOString(),containsSecrets:false,config:publicConfig(config.value)});return;
   }
   if(url.pathname==='/api/docs'&&req.method==='GET'){
    const docs={installation:'Installation',configuration:'Configuration',integrations:'Integrations',architecture:'How Orbit works',security:'Security',troubleshooting:'Troubleshooting'};const doc=url.searchParams.get('doc')||'configuration';
    if(!Object.hasOwn(docs,doc)){json(res,404,{error:'Document not found'});return;}const file=path.join(root,'docs',doc+'.md');if(!fs.existsSync(file)){json(res,404,{error:'Documentation is not installed'});return;}json(res,200,{title:docs[doc],markdown:fs.readFileSync(file,'utf8')});return;
   }

   if(url.pathname==='/api/test-service'&&req.method==='POST'){
    const input=await readBody();if(!input||typeof input!=='object'||Array.isArray(input))throw new InputError('Expected connection settings');
    const saved=input.serviceId?config.get(input.serviceId):undefined;if(input.serviceId&&!saved)throw new InputError('Source not found');
    const service=validateService(input.settings,saved);if(noCollector(service))throw new InputError('This source is a bookmark. Select a collector to test measurements.');if(!configured(service))throw new InputError('Enter a collection address first.');
    if(connectionTests.size>=2){json(res,429,{error:'Two connection tests are already running. Please wait for one to finish.'});return;}
    const id='test-'+randomUUID(),controller=new AbortController(),started=Date.now();connectionTests.set(id,controller);
    const cancel=()=>controller.abort();res.once('close',cancel);
    try{const metrics=await collectLogical({...service,id},controller.signal);if(controller.signal.aborted)throw new Error('Connection test exceeded its time limit.');if(!res.destroyed)json(res,200,{ok:true,metrics,elapsedMs:Date.now()-started,checkedAt:Date.now()});}
    catch(e){if(!res.destroyed)json(res,422,{error:controller.signal.aborted?'Connection test exceeded its time limit.':collectionError(e,service)});}
    finally{res.off('close',cancel);connectionTests.delete(id);resetCollector(id);}return;
   }
   if(url.pathname==='/api/settings'&&req.method==='PATCH'){const previousEmail=JSON.stringify(config.value.email),previousMonitoring=JSON.stringify(config.value.monitoring);const previousAlertEnabled=config.value.alerts.enabled,previousPoll=config.value.pollSeconds,previousRetention=config.value.retentionDays;config.updateGlobal(await readBody());if(JSON.stringify(config.value.email)!==previousEmail)email.reconfigure();if(previousAlertEnabled!==config.value.alerts.enabled)store.clearAllAlerts();if(previousMonitoring!==JSON.stringify(config.value.monitoring)){for(const controller of inflight.values())controller.abort();due.clear();}if(previousPoll!==config.value.pollSeconds)due.clear();if(previousRetention!==config.value.retentionDays)store.prune(config.value.retentionDays);json(res,200,{ok:true});return;}
   if(url.pathname==='/api/email/test'&&req.method==='POST'){
    if(!auth.required){json(res,403,{error:'Set an Orbit login password before sending test email.'});return;}
    const input=await readBody();if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length)throw new InputError('Test email uses saved settings. Save email settings first.');
    if(!emailConfigured(config.value.email))throw new InputError('Save a sender, recipient and app password before sending a test email.');
    if(Date.now()<nextEmailTest||email.status().pending){res.setHeader('Retry-After',String(Math.max(1,Math.ceil((nextEmailTest-Date.now())/1000))));json(res,429,{error:'Please wait one minute between test emails and let any current delivery finish.'});return;}
    nextEmailTest=Date.now()+60000;
    try{const result=await email.send({name:'Orbit',time:Date.now()},{test:true});if(!result.accepted){json(res,409,{error:'Email settings changed before the test was sent. Save settings and try again.'});return;}json(res,200,{ok:true,accepted:true,message:'The mail server accepted the test email. Check the inbox and spam folder.',acceptedAt:result.acceptedAt});}
    catch(error){json(res,error.code==='EMAIL_BUSY'?429:422,{error:error.message});}return;
   }
   if(url.pathname==='/api/services'&&req.method==='POST'){const service=config.add(await readBody());due.delete(service.id);json(res,201,{service:publicConfig({services:[service]}).services[0]});return;}
   const match=url.pathname.match(/^\/api\/services\/([\w-]+)$/);
   if(match){const id=match[1];const old=config.get(id);if(!old){json(res,404,{error:'Source not found'});return;}if(req.method==='PATCH'){const service=config.update(id,await readBody());const measurementsChanged=collectorType(old)!==collectorType(service)||(old.nodeName||'')!==(service.nodeName||'');if(measurementsChanged)store.clearAlerts(id);else store.reconcileRules(id,old.rules,service.rules);inflight.get(id)?.abort();resetCollector(id);if(!service.enabled||!configured(service)){store.clearAlerts(id);store.markGap(id);}if(measurementsChanged||old.enabled!==service.enabled)store.markGap(id);due.delete(id);json(res,200,{service:publicConfig({services:[service]}).services[0]});return;}if(req.method==='DELETE'){config.remove(id);inflight.get(id)?.abort();resetCollector(id);store.forget(id);due.delete(id);json(res,200,{ok:true});return;}}
   const history=url.pathname.match(/^\/api\/history\/([\w-]+)$/);
   if(history&&req.method==='GET'){if(!config.get(history[1])){json(res,404,{error:'Source not found'});return;}const period=url.searchParams.get('range')||'24h';if(!periods[period])throw new InputError('Unknown history period');json(res,200,{...store.history(history[1],period,Date.now(),interval(config.get(history[1]))),pollSeconds:interval(config.get(history[1]))});return;}
   if(url.pathname==='/api/refresh'&&req.method==='POST'){due.clear();void tick().catch(()=>console.error('Collector refresh failed'));json(res,202,{ok:true});return;}
   if(url.pathname==='/health'&&req.method==='GET'){json(res,200,{status:'ok'});return;}
   if(url.pathname.startsWith('/api/')){json(res,404,{error:'Route not found'});return;}
   if(!['GET','HEAD'].includes(req.method)){json(res,405,{error:'Method not allowed'});return;}
   const files={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js','/favicon.svg':'favicon.svg'};const name=files[url.pathname];if(!name){res.writeHead(404);res.end('Not found');return;}
   const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml'};res.writeHead(200,{'Content-Type':mime[path.extname(name)],'Cache-Control':'no-cache'});if(req.method==='HEAD')res.end();else fs.createReadStream(path.join(root,'public',name)).pipe(res);
  }catch(e){if(e instanceof AuthError){if(e.status===401)res.setHeader('WWW-Authenticate','Basic realm="Orbit", charset="UTF-8"');if(e.status===429)res.setHeader('Retry-After','1');json(res,e.status,{error:e.message});return;}json(res,e instanceof InputError?400:500,{error:e instanceof InputError?e.message:'Orbit could not complete this request'});if(!(e instanceof InputError))console.error('Request failed:',e.code||e.name);}
 });
 const timer=startScheduler?setInterval(()=>{void tick().catch(()=>console.error('Collector scheduler error'));},1000):null;
 return {server,store,config,dashboard,poll,tick,flushNotifications:()=>Promise.all([...notificationsPending]),listen:()=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>resolve(server.address()));}),close:async()=>{closed=true;if(timer)clearInterval(timer);for(const controller of [...inflight.values(),...connectionTests.values()])controller.abort();await email.close();await Promise.all([...notificationsPending]);await new Promise(resolve=>server.close(resolve));store.close();}};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 process.umask(0o077);
 try{const app=createApp();const addr=await app.listen();console.log(`Orbit is ready at http://${addr.address.includes(':')?'['+addr.address+']':addr.address}:${addr.port}`);for(const signal of ['SIGINT','SIGTERM'])process.on(signal,async()=>{await app.close();process.exit(0);});}catch(e){console.error(e.message);process.exit(1);}
}
